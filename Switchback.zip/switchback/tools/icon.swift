// Draws Switchback's icon: a forest-green poster with a sand mountain and a rust switchback trail.
// Usage: swift tools/icon.swift App/Assets.xcassets/AppIcon.appiconset/icon-1024.png
import AppKit
import CoreGraphics

let size = 1024.0
let space = CGColorSpace(name: CGColorSpace.sRGB)!
let ctx = CGContext(data: nil, width: Int(size), height: Int(size), bitsPerComponent: 8, bytesPerRow: 0, space: space, bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)!
func color(_ hex: UInt32) -> CGColor {
  CGColor(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255, blue: CGFloat(hex & 0xFF) / 255, alpha: 1)
}
func poly(_ points: [(Double, Double)], _ fill: CGColor) {
  ctx.beginPath()
  ctx.move(to: CGPoint(x: points[0].0, y: points[0].1))
  points.dropFirst().forEach { ctx.addLine(to: CGPoint(x: $0.0, y: $0.1)) }
  ctx.closePath()
  ctx.setFillColor(fill)
  ctx.fillPath()
}
// Origin is bottom-left.
ctx.setFillColor(color(0x1F4D3A)); ctx.fill(CGRect(x: 0, y: 0, width: size, height: size))
ctx.setFillColor(color(0xFBE3B0)); ctx.fillEllipse(in: CGRect(x: 640, y: 690, width: 190, height: 190))
poly([(-40, 120), (420, 760), (600, 520), (700, 640), (1064, 120)], color(0xF2E3C9))
poly([(-40, 0), (-40, 160), (1064, 160), (1064, 0)], color(0x163A2C))
ctx.setStrokeColor(color(0xC24A1F)); ctx.setLineWidth(46); ctx.setLineCap(.round); ctx.setLineJoin(.round)
ctx.move(to: CGPoint(x: 250, y: 230)); ctx.addLine(to: CGPoint(x: 560, y: 230)); ctx.addLine(to: CGPoint(x: 380, y: 380))
ctx.addLine(to: CGPoint(x: 560, y: 380)); ctx.addLine(to: CGPoint(x: 410, y: 520)); ctx.addLine(to: CGPoint(x: 500, y: 600))
ctx.strokePath()
let rep = NSBitmapImageRep(cgImage: ctx.makeImage()!)
try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
