"""Builds Switchback's bundled park data from the NPS API.

Usage: python3 tools/build_data.py [API_KEY]
Writes App/Resources/Data/parks.json and App/Resources/Data/guides/<code>.json.
Raw API responses are cached in .data/ so a rerun doesn't spend the rate limit again.
"""
import html
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, ".data")
OUT = os.path.join(ROOT, "App", "Resources", "Data")
KEY = sys.argv[1] if len(sys.argv) > 1 else "DEMO_KEY"
API = "https://developer.nps.gov/api/v1"
PAGE = 500

# Explore filters. A park can sit under several.
CATEGORIES = {
    "acad": ["coast", "forest"], "arch": ["desert"], "badl": ["desert"], "bibe": ["desert", "mountains"],
    "bisc": ["coast"], "blca": ["mountains"], "brca": ["desert"], "cany": ["desert"], "care": ["desert"],
    "cave": ["caves", "desert"], "chir": ["mountains", "desert"], "chis": ["coast"], "cong": ["forest"],
    "crla": ["mountains", "volcanoes"], "cuva": ["forest"], "dena": ["mountains"], "deva": ["desert"],
    "drto": ["coast"], "ever": ["coast"], "gaar": ["mountains"], "glac": ["mountains"],
    "glba": ["coast", "mountains"], "grba": ["mountains", "desert", "caves"], "grca": ["desert"],
    "grsa": ["desert", "mountains"], "grsm": ["mountains", "forest"], "grte": ["mountains"],
    "gumo": ["mountains", "desert"], "hale": ["volcanoes", "mountains"], "havo": ["volcanoes", "coast"],
    "hosp": ["forest"], "indu": ["coast"], "isro": ["coast", "forest"], "jeff": [], "jotr": ["desert"],
    "katm": ["mountains", "volcanoes", "coast"], "kefj": ["coast", "mountains"], "kova": ["mountains"],
    "lacl": ["mountains", "volcanoes", "coast"], "lavo": ["volcanoes", "mountains"], "maca": ["caves", "forest"],
    "meve": ["desert"], "mora": ["mountains", "volcanoes"], "neri": ["forest"], "noca": ["mountains"],
    "npsa": ["coast"], "olym": ["mountains", "coast", "forest"], "pefo": ["desert"], "pinn": ["mountains"],
    "redw": ["forest", "coast"], "romo": ["mountains"], "sagu": ["desert"], "seki": ["mountains", "forest"],
    "shen": ["mountains", "forest"], "thro": ["desert"], "viis": ["coast"], "voya": ["forest", "coast"],
    "whsa": ["desert"], "wica": ["caves"], "wrst": ["mountains"], "yell": ["mountains", "volcanoes"],
    "yose": ["mountains"], "zion": ["desert", "mountains"],
}

# Each park's local time zone, for sunrise and sunset in park time wherever the phone is.
TIMEZONES = {
    "acad": "America/New_York", "arch": "America/Denver", "badl": "America/Denver", "bibe": "America/Chicago",
    "bisc": "America/New_York", "blca": "America/Denver", "brca": "America/Denver", "cany": "America/Denver",
    "care": "America/Denver", "cave": "America/Denver", "chir": "America/Phoenix", "chis": "America/Los_Angeles",
    "cong": "America/New_York", "crla": "America/Los_Angeles", "cuva": "America/New_York", "dena": "America/Anchorage",
    "deva": "America/Los_Angeles", "drto": "America/New_York", "ever": "America/New_York", "gaar": "America/Anchorage",
    "glac": "America/Denver", "glba": "America/Juneau", "grba": "America/Los_Angeles", "grca": "America/Phoenix",
    "grsa": "America/Denver", "grsm": "America/New_York", "grte": "America/Denver", "gumo": "America/Denver",
    "hale": "Pacific/Honolulu", "havo": "Pacific/Honolulu", "hosp": "America/Chicago", "indu": "America/Chicago",
    "isro": "America/Detroit", "jeff": "America/Chicago", "jotr": "America/Los_Angeles", "katm": "America/Anchorage",
    "kefj": "America/Anchorage", "kova": "America/Anchorage", "lacl": "America/Anchorage", "lavo": "America/Los_Angeles",
    "maca": "America/Chicago", "meve": "America/Denver", "mora": "America/Los_Angeles", "neri": "America/New_York",
    "noca": "America/Los_Angeles", "npsa": "Pacific/Pago_Pago", "olym": "America/Los_Angeles", "pefo": "America/Phoenix",
    "pinn": "America/Los_Angeles", "redw": "America/Los_Angeles", "romo": "America/Denver", "sagu": "America/Phoenix",
    "seki": "America/Los_Angeles", "shen": "America/New_York", "thro": "America/Denver", "viis": "America/St_Thomas",
    "voya": "America/Chicago", "whsa": "America/Denver", "wica": "America/Denver", "wrst": "America/Anchorage",
    "yell": "America/Denver", "yose": "America/Los_Angeles", "zion": "America/Denver",
}


def get(path, params, cache_name):
    cached = os.path.join(CACHE, cache_name)
    if os.path.exists(cached):
        with open(cached) as f:
            return json.load(f)
    # The API reads a park list only with literal commas.
    query = urllib.parse.urlencode({**params, "api_key": KEY}, safe=",")
    url = f"{API}/{path}?{query}"
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as response:
                remaining = response.headers.get("X-RateLimit-Remaining")
                data = json.load(response)
            print(f"  {path} start={params.get('start', 0)}: {len(data.get('data', []))} of {data.get('total')} (left: {remaining})")
            with open(cached, "w") as f:
                json.dump(data, f)
            return data
        except Exception as error:  # noqa: BLE001 - retry any network hiccup
            print(f"  retry {path}: {error}")
            time.sleep(5 * (attempt + 1))
    raise SystemExit(f"Couldn't fetch {path}")


PARTIAL = os.environ.get("PARTIAL") == "1"


def fetch_all(path, codes):
    items, start = [], 0
    while True:
        # With PARTIAL=1, build from whatever pages are already cached instead of fetching.
        if PARTIAL and not os.path.exists(os.path.join(CACHE, f"{path}_{start}.json")):
            print(f"  {path}: using {len(items)} cached items")
            return items
        data = get(path, {"parkCode": ",".join(codes), "limit": PAGE, "start": start}, f"{path}_{start}.json")
        batch = data.get("data", [])
        items += batch
        start += PAGE
        if not batch or start >= int(data.get("total", 0)):
            return items


def clean(text, limit=None):
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>|</p>|</li>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text).strip()
    if limit and len(text) > limit:
        cut = text[:limit].rsplit(" ", 1)[0]
        text = cut + "…"
    return text


def number(value):
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        return None


def park_codes(item):
    codes = {p.get("parkCode") for p in item.get("relatedParks", []) if p.get("parkCode")}
    if item.get("parkCode"):
        codes.add(item["parkCode"])
    return codes


def first_image(item):
    images = item.get("images") or []
    if not images:
        return None
    image = images[0]
    return {"url": image.get("url"), "alt": clean(image.get("altText")), "credit": clean(image.get("credit"))}


def main():
    os.makedirs(CACHE, exist_ok=True)
    os.makedirs(os.path.join(OUT, "guides"), exist_ok=True)
    with open(os.path.join(CACHE, "parks_all.json")) as f:
        everything = json.load(f)["data"]
    parks = [p for p in everything if p["parkCode"] in CATEGORIES]
    codes = sorted(p["parkCode"] for p in parks)
    print(f"{len(codes)} parks")

    todo = fetch_all("thingstodo", codes)
    places = fetch_all("places", codes)
    centers = fetch_all("visitorcenters", codes)
    camps = fetch_all("campgrounds", codes)

    index = []
    for park in sorted(parks, key=lambda p: p["fullName"]):
        code = park["parkCode"]
        hikes, other = [], []
        for item in todo:
            if code not in park_codes(item):
                continue
            activities = [a.get("name") for a in item.get("activities", [])]
            entry = {
                "id": item.get("id"),
                "title": clean(item.get("title")),
                "summary": clean(item.get("shortDescription"), 400),
                "body": clean(item.get("longDescription"), 2400),
                "duration": clean(item.get("duration")),
                "season": item.get("season") or [],
                "timeOfDay": item.get("timeOfDay") or [],
                "pets": clean(item.get("petsDescription"), 300),
                "fees": item.get("doFeesApply") == "true",
                "reservation": item.get("isReservationRequired") == "true",
                "accessibility": clean(item.get("accessibilityInformation"), 400),
                "activities": activities,
                "lat": number(item.get("latitude")),
                "lon": number(item.get("longitude")),
                "image": first_image(item),
            }
            title = (item.get("title") or "").lower()
            is_hike = any("hik" in (a or "").lower() for a in activities) or any(w in title for w in ("hike", "trail", "walk"))
            (hikes if is_hike else other).append(entry)
        views = []
        for item in places:
            if code not in park_codes(item):
                continue
            tags = item.get("tags") or []
            views.append({
                "id": item.get("id"),
                "title": clean(item.get("title")),
                "summary": clean(item.get("listingDescription"), 400),
                "body": clean(item.get("bodyText"), 1800),
                "tags": tags,
                "lat": number(item.get("latitude")),
                "lon": number(item.get("longitude")),
                "image": first_image(item),
            })
        visitor = [{
            "name": clean(c.get("name")),
            "summary": clean(c.get("description"), 400),
            "directions": clean(c.get("directionsInfo"), 400),
            "lat": number(c.get("latitude")),
            "lon": number(c.get("longitude")),
            "phone": next((p.get("phoneNumber") for p in (c.get("contacts", {}) or {}).get("phoneNumbers", []) if p.get("type") == "Voice"), None),
        } for c in centers if code in park_codes(c)]
        camping = [{
            "name": clean(c.get("name")),
            "summary": clean(c.get("description"), 500),
            "reservation": clean(c.get("reservationInfo"), 300),
            "sites": (c.get("campsites") or {}).get("totalSites"),
            "lat": number(c.get("latitude")),
            "lon": number(c.get("longitude")),
        } for c in camps if code in park_codes(c)]

        states = park.get("states", "")
        guide = {
            "code": code,
            "name": park["name"],
            "fullName": park["fullName"],
            "states": states,
            "description": clean(park.get("description"), 1600),
            "weather": clean(park.get("weatherInfo"), 1200),
            "directions": clean(park.get("directionsInfo"), 1200),
            "fees": [{"title": clean(f.get("title")), "cost": f.get("cost"), "summary": clean(f.get("description"), 300)} for f in park.get("entranceFees", [])][:6],
            "hours": [{"name": clean(h.get("name")), "summary": clean(h.get("description"), 500)} for h in park.get("operatingHours", [])][:6],
            "phone": next((p.get("phoneNumber") for p in park.get("contacts", {}).get("phoneNumbers", []) if p.get("type") == "Voice"), None),
            "hikes": hikes,
            "activities": other,
            "places": views,
            "visitorCenters": visitor,
            "campgrounds": camping,
        }
        with open(os.path.join(OUT, "guides", f"{code}.json"), "w") as f:
            json.dump(guide, f, separators=(",", ":"))
        index.append({
            "code": code,
            "name": park["name"],
            "fullName": park["fullName"],
            "designation": park.get("designation") or "National Park",
            "states": states,
            "timeZone": TIMEZONES[code],
            "lat": number(park.get("latitude")),
            "lon": number(park.get("longitude")),
            "summary": clean(park.get("description"), 280),
            "categories": CATEGORIES[code],
            "image": first_image(park),
            "hikeCount": len(hikes),
            "placeCount": len(views),
        })
    with open(os.path.join(OUT, "parks.json"), "w") as f:
        json.dump(index, f, separators=(",", ":"))
    total = sum(os.path.getsize(os.path.join(OUT, "guides", n)) for n in os.listdir(os.path.join(OUT, "guides")))
    print(f"Wrote {len(index)} parks; guides {total / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
