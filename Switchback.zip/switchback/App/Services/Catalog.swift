import Foundation

/// The parks and guides that ship inside the app, so every park works with no signal.
final class Catalog {
  let parks: [ParkSummary]
  private var guides: [String: ParkGuide] = [:]

  init() {
    parks = Self.decode([ParkSummary].self, at: "Data/parks.json") ?? []
  }

  func park(_ code: String) -> ParkSummary? {
    parks.first { $0.code == code }
  }

  func guide(_ code: String) -> ParkGuide? {
    if let cached = guides[code] {
      return cached
    }
    let guide = Self.decode(ParkGuide.self, at: "Data/guides/\(code).json")
    guides[code] = guide
    return guide
  }

  func search(_ query: String, in category: ParkCategory? = nil) -> [ParkSummary] {
    let text = query.trimmingCharacters(in: .whitespaces).lowercased()
    return parks.filter { park in
      let matchesCategory = category.map { park.categories.contains($0.rawValue) } ?? true
      guard matchesCategory else {
        return false
      }
      guard !text.isEmpty else {
        return true
      }
      return park.name.lowercased().contains(text) || park.stateNames.lowercased().contains(text) || park.states.lowercased() == text
    }
  }

  private static func decode<T: Decodable>(_ type: T.Type, at path: String) -> T? {
    guard let url = Bundle.main.resourceURL?.appending(path: path), let data = try? Data(contentsOf: url) else {
      return nil
    }
    return try? JSONDecoder().decode(type, from: data)
  }
}
