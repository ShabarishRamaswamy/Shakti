import Foundation
import Observation

/// Downloads a park for offline use and keeps what was saved: trails with elevation, topo map
/// tiles and the latest alerts.
@Observable
final class ParkStore {
  enum Step: CaseIterable, Hashable {
    case map
    case trails
    case guide
    case light
    case alerts

    var title: String {
      switch self {
      case .map: "Topographic map"
      case .trails: "Trails and elevation"
      case .guide: "Ranger guide"
      case .light: "Viewpoints and sun times"
      case .alerts: "Park alerts"
      }
    }
  }

  enum StepState: Equatable {
    case waiting
    case working
    case done
    case onlineOnly
    case failed(String)

    var label: String {
      switch self {
      case .waiting: "Next"
      case .working: "Saving"
      case .done: "Done"
      case .onlineOnly: "When online"
      case .failed: "Couldn't save"
      }
    }
  }

  struct Progress: Equatable {
    var fraction = 0.0
    var steps: [Step: StepState] = Dictionary(uniqueKeysWithValues: Step.allCases.map { ($0, .waiting) })
  }

  private(set) var packs: [String: ParkPack] = [:]
  private(set) var progress: [String: Progress] = [:]
  private(set) var alerts: [String: AlertSet] = [:]
  private var tasks: [String: Task<Void, Never>] = [:]

  private static let tileBudget = 4500
  private static let minZoom = 9
  private static let featuredTrails = 30
  private static let parallelTiles = 8

  init() {
    loadSaved()
  }

  func isReady(_ code: String) -> Bool {
    packs[code] != nil && progress[code] == nil
  }

  func isDownloading(_ code: String) -> Bool {
    progress[code] != nil
  }

  func trail(_ id: String, in code: String) -> Trail? {
    packs[code]?.trails.first { $0.id == id }
  }

  // MARK: Download

  func download(_ park: ParkSummary, guide: ParkGuide?) {
    guard tasks[park.code] == nil else {
      return
    }
    progress[park.code] = Progress()
    tasks[park.code] = Task {
      await run(park, guide: guide)
      tasks[park.code] = nil
    }
  }

  func cancel(_ code: String) {
    tasks[code]?.cancel()
    tasks[code] = nil
    progress[code] = nil
  }

  func remove(_ code: String) {
    cancel(code)
    try? FileManager.default.removeItem(at: Storage.parkFolder(code))
    packs[code] = nil
    alerts[code] = nil
  }

  private func run(_ park: ParkSummary, guide: ParkGuide?) async {
    let code = park.code
    set(code, .guide, guide == nil ? .failed("Missing") : .done)
    set(code, .light, .done)

    set(code, .trails, .working)
    var trails = (try? await TrailSource.fetch(unit: code)) ?? []
    guard !Task.isCancelled else {
      return
    }
    let featured = Self.featured(trails, guide: guide)
    for (offset, index) in featured.enumerated() {
      guard !Task.isCancelled else {
        return
      }
      if let profile = try? await ElevationSource.profile(for: trails[index].path) {
        trails[index].setProfile(profile)
      }
      advance(code, to: 0.05 + 0.2 * Double(offset + 1) / Double(max(1, featured.count)))
    }
    set(code, .trails, trails.isEmpty ? .failed("No mapped trails") : .done)

    set(code, .map, .working)
    let coords = trails.flatMap(\.path)
    let fallback = park.coordinate.map { Coord($0) } ?? Coord(0, 0)
    let area = (BBox(coords) ?? BBox(minLat: fallback.lat - 0.15, minLon: fallback.lon - 0.15, maxLat: fallback.lat + 0.15, maxLon: fallback.lon + 0.15)).padded(by: 0.08)
    let plan = TilePlan(bbox: area, minZoom: Self.minZoom, budget: Self.tileBudget)
    let saved = await downloadTiles(plan, code: code)
    guard !Task.isCancelled else {
      return
    }
    set(code, .map, saved > plan.tiles.count / 2 ? .done : .failed("Saved \(saved) of \(plan.tiles.count)"))

    set(code, .alerts, .working)
    if let fetched = try? await AlertSource.fetch(park: code) {
      alerts[code] = fetched
      save(fetched, as: "alerts.json", in: code)
      set(code, .alerts, .done)
    } else {
      set(code, .alerts, .onlineOnly)
    }

    let pack = ParkPack(code: code, trails: trails, bbox: area, minZoom: plan.minZoom, maxZoom: plan.maxZoom, tileCount: saved, savedAt: Date())
    save(pack, as: "pack.json", in: code)
    packs[code] = pack
    advance(code, to: 1)
    try? await Task.sleep(for: .seconds(1))
    progress[code] = nil
  }

  private func downloadTiles(_ plan: TilePlan, code: String) async -> Int {
    var saved = 0
    var done = 0
    let total = plan.tiles.count
    await withTaskGroup(of: Bool.self) { group in
      var iterator = plan.tiles.makeIterator()
      func addNext() -> Bool {
        guard let tile = iterator.next() else {
          return false
        }
        group.addTask { await TileSource.save(tile, park: code) }
        return true
      }
      for _ in 0..<Self.parallelTiles where addNext() {}
      for await ok in group {
        done += 1
        if ok {
          saved += 1
        }
        if done % 25 == 0 || done == total {
          advance(code, to: 0.25 + 0.7 * Double(done) / Double(max(1, total)))
        }
        if Task.isCancelled {
          group.cancelAll()
          break
        }
        _ = addNext()
      }
    }
    return saved
  }

  /// Trails that get an elevation profile: ones the park's guide talks about, then the longest.
  private static func featured(_ trails: [Trail], guide: ParkGuide?) -> [Int] {
    let hikeTitles = (guide?.hikes ?? []).map { normalize($0.title) }
    let mentioned = trails.indices.filter { index in
      let name = normalize(trails[index].name)
      return !name.isEmpty && hikeTitles.contains { $0.contains(name) || name.contains($0) }
    }
    let longest = trails.indices.sorted { trails[$0].length > trails[$1].length }
    var picked: [Int] = []
    for index in mentioned + longest where !picked.contains(index) && picked.count < featuredTrails {
      picked.append(index)
    }
    return picked
  }

  static func normalize(_ name: String) -> String {
    name.lowercased()
      .replacingOccurrences(of: "trail", with: "")
      .replacingOccurrences(of: "hike", with: "")
      .replacingOccurrences(of: "the ", with: "")
      .components(separatedBy: CharacterSet.alphanumerics.inverted)
      .filter { !$0.isEmpty }
      .joined(separator: " ")
  }

  // MARK: Elevation on demand and alerts

  /// Fetches a profile for a trail opened later, when there's signal.
  func ensureProfile(_ trailID: String, in code: String) async {
    guard var pack = packs[code], let index = pack.trails.firstIndex(where: { $0.id == trailID }), pack.trails[index].profile == nil else {
      return
    }
    guard let profile = try? await ElevationSource.profile(for: pack.trails[index].path) else {
      return
    }
    var trails = pack.trails
    trails[index].setProfile(profile)
    pack = ParkPack(code: pack.code, trails: trails, bbox: pack.bbox, minZoom: pack.minZoom, maxZoom: pack.maxZoom, tileCount: pack.tileCount, savedAt: pack.savedAt)
    packs[code] = pack
    save(pack, as: "pack.json", in: code)
  }

  func refreshAlerts(_ code: String) async {
    if let current = alerts[code], Date().timeIntervalSince(current.fetchedAt) < 3600 {
      return
    }
    guard let fetched = try? await AlertSource.fetch(park: code) else {
      return
    }
    alerts[code] = fetched
    save(fetched, as: "alerts.json", in: code)
  }

  // MARK: Disk

  private func loadSaved() {
    let base = Storage.parkFolder("x").deletingLastPathComponent()
    let codes = (try? FileManager.default.contentsOfDirectory(atPath: base.path)) ?? []
    for code in codes {
      let folder = Storage.parkFolder(code)
      if let data = try? Data(contentsOf: folder.appending(path: "pack.json")), let pack = try? JSONDecoder().decode(ParkPack.self, from: data) {
        packs[code] = pack
      }
      if let data = try? Data(contentsOf: folder.appending(path: "alerts.json")), let set = try? JSONDecoder().decode(AlertSet.self, from: data) {
        alerts[code] = set
      }
    }
  }

  private func save(_ value: some Encodable, as name: String, in code: String) {
    guard let data = try? JSONEncoder().encode(value) else {
      return
    }
    try? data.write(to: Storage.parkFolder(code).appending(path: name), options: .atomic)
  }

  private func set(_ code: String, _ step: Step, _ state: StepState) {
    progress[code]?.steps[step] = state
  }

  private func advance(_ code: String, to fraction: Double) {
    // Read first, then write: reading inside the assignment overlaps the write and traps.
    let current = progress[code]?.fraction ?? 0
    progress[code]?.fraction = min(1, max(current, fraction))
  }
}

/// Which map tiles to save: everything in the box from `minZoom` up to the deepest zoom that
/// fits the budget.
nonisolated struct TilePlan: Sendable {
  struct Tile: Hashable, Sendable {
    let z: Int
    let x: Int
    let y: Int
  }

  let tiles: [Tile]
  let minZoom: Int
  let maxZoom: Int

  init(bbox: BBox, minZoom: Int, budget: Int) {
    var chosen: [Tile] = []
    var deepest = minZoom
    for z in minZoom...16 {
      let level = Self.tiles(in: bbox, z: z)
      guard chosen.count + level.count <= budget || z == minZoom else {
        break
      }
      chosen += level
      deepest = z
    }
    tiles = chosen
    self.minZoom = minZoom
    maxZoom = deepest
  }

  static func tiles(in box: BBox, z: Int) -> [Tile] {
    let (x0, y0) = index(lat: box.maxLat, lon: box.minLon, z: z)
    let (x1, y1) = index(lat: box.minLat, lon: box.maxLon, z: z)
    var result: [Tile] = []
    for x in min(x0, x1)...max(x0, x1) {
      for y in min(y0, y1)...max(y0, y1) {
        result.append(Tile(z: z, x: x, y: y))
      }
    }
    return result
  }

  static func index(lat: Double, lon: Double, z: Int) -> (Int, Int) {
    let n = pow(2.0, Double(z))
    let x = Int(floor((lon + 180) / 360 * n))
    let rad = lat * .pi / 180
    let y = Int(floor((1 - log(tan(rad) + 1 / cos(rad)) / .pi) / 2 * n))
    return (max(0, min(Int(n) - 1, x)), max(0, min(Int(n) - 1, y)))
  }
}
