import Foundation

/// The NPS API key. The demo key works for personal use with a low hourly limit; a free key from
/// nps.gov/subjects/developer lifts it for release.
nonisolated enum NPSAPI {
  static let key = "DEMO_KEY"
  static let base = "https://developer.nps.gov/api/v1"
}

nonisolated enum SourceError: Error {
  case badResponse
}

/// Trail routes from the NPS Public Trails data (public domain).
nonisolated enum TrailSource {
  private static let endpoint = "https://mapservices.nps.gov/arcgis/rest/services/NationalDatasets/NPS_Public_Trails_Geographic/FeatureServer/0/query"
  private static let pageSize = 2000
  /// Pieces whose ends are this close are treated as joined.
  private static let joinDistance = 40.0
  private static let simplifyTolerance = 3.0
  private static let mainRouteShare = 0.7

  private struct Collection: Decodable {
    let features: [Feature]
    let exceededTransferLimit: Bool?
  }

  private struct Feature: Decodable {
    let properties: [String: Field]?
    let geometry: Geometry?
  }

  /// A property value; only text matters here, but ArcGIS mixes in numbers such as OBJECTID.
  private enum Field: Decodable {
    case text(String)
    case other

    init(from decoder: Decoder) throws {
      let container = try decoder.singleValueContainer()
      self = (try? container.decode(String.self)).map(Field.text) ?? .other
    }

    var text: String? {
      if case .text(let value) = self {
        return value
      }
      return nil
    }
  }

  private struct Geometry: Decodable {
    let type: String
    let coordinates: AnyCoordinates
  }

  /// LineString or MultiLineString coordinates.
  private enum AnyCoordinates: Decodable {
    case line([[Double]])
    case multi([[[Double]]])

    init(from decoder: Decoder) throws {
      let container = try decoder.singleValueContainer()
      if let multi = try? container.decode([[[Double]]].self) {
        self = .multi(multi)
      } else {
        self = .line(try container.decode([[Double]].self))
      }
    }

    var lines: [[Coord]] {
      switch self {
      case .line(let points): [points.compactMap(Self.coord)]
      case .multi(let lines): lines.map { $0.compactMap(Self.coord) }
      }
    }

    private static func coord(_ pair: [Double]) -> Coord? {
      pair.count >= 2 ? Coord(pair[1], pair[0]) : nil
    }
  }

  static func fetch(unit code: String) async throws -> [Trail] {
    var pieces: [String: (segments: [[Coord]], surface: String?, seasonal: Bool)] = [:]
    var offset = 0
    while true {
      var components = URLComponents(string: endpoint)!
      components.queryItems = [
        URLQueryItem(name: "where", value: "UNITCODE='\(code.uppercased())'"),
        URLQueryItem(name: "outFields", value: "TRLNAME,TRLSTATUS,TRLSURFACE,SEASONAL,TRLUSE"),
        URLQueryItem(name: "outSR", value: "4326"),
        URLQueryItem(name: "f", value: "geojson"),
        URLQueryItem(name: "resultOffset", value: String(offset)),
        URLQueryItem(name: "resultRecordCount", value: String(pageSize))
      ]
      let (data, response) = try await URLSession.shared.data(from: components.url!)
      guard (response as? HTTPURLResponse)?.statusCode == 200 else {
        throw SourceError.badResponse
      }
      let page = try JSONDecoder().decode(Collection.self, from: data)
      for feature in page.features {
        let props = feature.properties ?? [:]
        guard let rawName = props["TRLNAME"]?.text, let geometry = feature.geometry else {
          continue
        }
        let name = rawName.trimmingCharacters(in: .whitespaces)
        let status = props["TRLSTATUS"]?.text?.lowercased() ?? "existing"
        let use = props["TRLUSE"]?.text?.lowercased() ?? ""
        guard !name.isEmpty, !["unknown", "unnamed", "none"].contains(name.lowercased()), status == "existing", !use.contains("motor") else {
          continue
        }
        var entry = pieces[name] ?? (segments: [], surface: props["TRLSURFACE"]?.text, seasonal: false)
        entry.segments += geometry.coordinates.lines.map { Geo.simplify($0, tolerance: simplifyTolerance) }.filter { $0.count > 1 }
        entry.seasonal = entry.seasonal || props["SEASONAL"]?.text == "Yes"
        pieces[name] = entry
      }
      guard page.exceededTransferLimit == true || page.features.count == pageSize else {
        break
      }
      offset += pageSize
    }
    return pieces.map { name, entry in
      let path = chain(entry.segments)
      let loopGap = path.count > 2 ? Geo.distance(path[0], path[path.count - 1]) : .infinity
      let length = entry.segments.reduce(0) { $0 + Geo.length($1) }
      let pathLength = Geo.length(path)
      // When the joined route is much shorter than everything with this name, the rest is spurs.
      let routeLength = pathLength / max(1, length) < mainRouteShare ? pathLength : length
      return Trail(
        id: name.lowercased().replacingOccurrences(of: " ", with: "-"),
        name: name,
        segments: entry.segments,
        path: path,
        length: length,
        routeLength: routeLength,
        isLoop: loopGap < 80 && routeLength > 400,
        surface: entry.surface,
        isSeasonal: entry.seasonal,
        profile: nil
      )
    }
    .filter { $0.length > 50 }
    .sorted { $0.name < $1.name }
  }

  /// Joins pieces end to end, greedily, starting from a loose end. Returns the longest run.
  static func chain(_ segments: [[Coord]]) -> [Coord] {
    guard !segments.isEmpty else {
      return []
    }
    var remaining = segments
    var runs: [[Coord]] = []
    while !remaining.isEmpty {
      let startIndex = remaining.indices.first { index in
        let start = remaining[index][0]
        return !remaining.enumerated().contains { other, piece in
          other != index && (piece[0].distance(to: start) < joinDistance || piece[piece.count - 1].distance(to: start) < joinDistance)
        }
      } ?? 0
      var run = remaining.remove(at: startIndex)
      var extended = true
      while extended {
        extended = false
        guard let end = run.last else {
          break
        }
        let candidates = remaining.enumerated().map { index, piece in
          (index, min(piece[0].distance(to: end), piece[piece.count - 1].distance(to: end)), piece[0].distance(to: end) <= piece[piece.count - 1].distance(to: end))
        }
        if let best = candidates.min(by: { $0.1 < $1.1 }), best.1 < joinDistance {
          let piece = remaining.remove(at: best.0)
          run += best.2 ? piece.dropFirst() : piece.reversed().dropFirst()
          extended = true
        }
      }
      runs.append(run)
    }
    return runs.max { Geo.length($0) < Geo.length($1) } ?? []
  }
}

/// Elevations from the USGS 3D Elevation Program (public domain).
nonisolated enum ElevationSource {
  private static let endpoint = "https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer/getSamples"

  private struct Response: Decodable {
    struct Sample: Decodable {
      let locationId: Int
      let value: String?
    }
    let samples: [Sample]
  }

  static func profile(for path: [Coord]) async throws -> [ProfilePoint] {
    let length = Geo.length(path)
    let count = max(12, min(80, Int(length / 40)))
    let points = Geo.resample(path, count: count)
    let geometry = [
      "points": points.map { [$0.0.lon, $0.0.lat] },
      "spatialReference": ["wkid": 4326]
    ] as [String: Any]
    let json = String(data: try JSONSerialization.data(withJSONObject: geometry), encoding: .utf8) ?? ""
    var request = URLRequest(url: URL(string: endpoint)!)
    request.httpMethod = "POST"
    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
    let body = [
      "geometry": json,
      "geometryType": "esriGeometryMultipoint",
      "returnFirstValueOnly": "true",
      "f": "json"
    ]
    request.httpBody = body.map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")" }.joined(separator: "&").data(using: .utf8)
    let (data, _) = try await URLSession.shared.data(for: request)
    let response = try JSONDecoder().decode(Response.self, from: data)
    let byLocation = Dictionary(response.samples.compactMap { sample in sample.value.flatMap(Double.init).map { (sample.locationId, $0) } }, uniquingKeysWith: { first, _ in first })
    let profile = points.enumerated().compactMap { index, point in
      byLocation[index].map { ProfilePoint(distance: point.1, elevation: $0) }
    }
    guard profile.count > 2 else {
      throw SourceError.badResponse
    }
    return profile
  }
}

/// USGS topographic map tiles (public domain), saved to disk for offline use.
nonisolated enum TileSource {
  static func url(z: Int, x: Int, y: Int) -> URL {
    URL(string: "https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/\(z)/\(y)/\(x)")!
  }

  static func save(_ tile: TilePlan.Tile, park code: String) async -> Bool {
    let destination = Storage.tileURL(park: code, z: tile.z, x: tile.x, y: tile.y)
    if FileManager.default.fileExists(atPath: destination.path) {
      return true
    }
    for attempt in 0..<2 {
      do {
        let (data, response) = try await URLSession.shared.data(from: url(z: tile.z, x: tile.x, y: tile.y))
        guard (response as? HTTPURLResponse)?.statusCode == 200, !data.isEmpty else {
          return false
        }
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        try data.write(to: destination)
        return true
      } catch {
        if attempt == 0 {
          try? await Task.sleep(for: .milliseconds(600))
        }
      }
    }
    return false
  }
}

/// Current alerts and closures from the NPS API.
nonisolated enum AlertSource {
  private struct Response: Decodable {
    struct Item: Decodable {
      let id: String
      let title: String
      let description: String
      let category: String
    }
    let data: [Item]
  }

  static func fetch(park code: String) async throws -> AlertSet {
    var components = URLComponents(string: "\(NPSAPI.base)/alerts")!
    components.queryItems = [URLQueryItem(name: "parkCode", value: code), URLQueryItem(name: "api_key", value: NPSAPI.key)]
    let (data, response) = try await URLSession.shared.data(from: components.url!)
    guard (response as? HTTPURLResponse)?.statusCode == 200 else {
      throw SourceError.badResponse
    }
    let decoded = try JSONDecoder().decode(Response.self, from: data)
    let alerts = decoded.data.map { ParkAlert(id: $0.id, title: $0.title, summary: $0.description, category: $0.category) }
    return AlertSet(alerts: alerts, fetchedAt: Date())
  }
}
