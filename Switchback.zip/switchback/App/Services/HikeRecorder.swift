import CoreLocation
import CoreMotion
import Foundation
import Observation
import UserNotifications

/// Records a hike: GPS track and distance, climbing from the barometer, moving time. It keeps going
/// with the screen locked and never sends the track anywhere.
@Observable
final class HikeRecorder: NSObject, CLLocationManagerDelegate {
  enum State {
    case idle
    case recording
    case paused
  }

  struct Finished {
    let park: ParkSummary
    let trailName: String
    let startedAt: Date
    let endedAt: Date
    let distance: Double
    let climb: Double
    let movingSeconds: Double
    let track: [Coord]
  }

  private(set) var state: State = .idle
  private(set) var park: ParkSummary?
  private(set) var trail: Trail?
  private(set) var startedAt: Date?
  private(set) var distance = 0.0
  private(set) var climb = 0.0
  private(set) var track: [Coord] = []
  private(set) var location: CLLocation?
  private(set) var authorization: CLAuthorizationStatus
  private var movingBefore = 0.0
  private var segmentStart: Date?
  private var lastAltitude: Double?
  private var altitudeBase: Double?
  private let manager = CLLocationManager()
  private let altimeter = CMAltimeter()
  private var background: CLBackgroundActivitySession?

  /// GPS fixes worse than this are ignored; steps shorter than `minimumStep` are jitter.
  private static let maximumAccuracy = 30.0
  private static let minimumStep = 4.0
  /// Barometer changes smaller than this are noise, not climbing.
  private static let climbStep = 1.5

  override init() {
    authorization = manager.authorizationStatus
    super.init()
    manager.delegate = self
    manager.activityType = .fitness
    manager.desiredAccuracy = kCLLocationAccuracyBest
    manager.distanceFilter = 3
  }

  var isActive: Bool { state != .idle }

  var movingSeconds: Double {
    movingBefore + (segmentStart.map { Date().timeIntervalSince($0) } ?? 0)
  }

  /// One-off position for "near me" and the map.
  func requestLocation() {
    if manager.authorizationStatus == .notDetermined {
      manager.requestWhenInUseAuthorization()
    }
    manager.requestLocation()
  }

  func start(park: ParkSummary, trail: Trail?) {
    self.park = park
    self.trail = trail
    startedAt = Date()
    segmentStart = Date()
    movingBefore = 0
    distance = 0
    climb = 0
    track = []
    lastAltitude = nil
    altitudeBase = nil
    state = .recording
    if manager.authorizationStatus == .notDetermined {
      manager.requestWhenInUseAuthorization()
    }
    background = CLBackgroundActivitySession()
    manager.allowsBackgroundLocationUpdates = true
    manager.showsBackgroundLocationIndicator = true
    manager.pausesLocationUpdatesAutomatically = false
    manager.startUpdatingLocation()
    startAltimeter()
  }

  func pause() {
    guard state == .recording else {
      return
    }
    movingBefore = movingSeconds
    segmentStart = nil
    state = .paused
  }

  func resume() {
    guard state == .paused else {
      return
    }
    segmentStart = Date()
    lastAltitude = nil
    state = .recording
  }

  func finish() -> Finished? {
    defer { reset() }
    guard let park, let startedAt else {
      return nil
    }
    return Finished(
      park: park,
      trailName: trail?.name ?? "A walk in \(park.name)",
      startedAt: startedAt,
      endedAt: Date(),
      distance: distance,
      climb: climb,
      movingSeconds: movingSeconds,
      track: track
    )
  }

  func discard() {
    reset()
  }

  private func reset() {
    manager.stopUpdatingLocation()
    manager.allowsBackgroundLocationUpdates = false
    altimeter.stopRelativeAltitudeUpdates()
    background?.invalidate()
    background = nil
    state = .idle
    segmentStart = nil
    trail = nil
  }

  private func startAltimeter() {
    guard CMAltimeter.isRelativeAltitudeAvailable() else {
      return
    }
    altimeter.startRelativeAltitudeUpdates(to: .main) { [weak self] data, _ in
      guard let meters = data?.relativeAltitude.doubleValue else {
        return
      }
      MainActor.assumeIsolated { self?.altitude(meters) }
    }
  }

  private func altitude(_ meters: Double) {
    guard state == .recording else {
      return
    }
    guard let last = lastAltitude else {
      lastAltitude = meters
      return
    }
    let change = meters - last
    if change > Self.climbStep {
      climb += change
      lastAltitude = meters
    } else if change < -Self.climbStep {
      lastAltitude = meters
    }
  }

  // MARK: CLLocationManagerDelegate

  nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    MainActor.assumeIsolated {
      for fix in locations {
        accept(fix)
      }
    }
  }

  nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: any Error) {}

  nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
    let status = manager.authorizationStatus
    MainActor.assumeIsolated { authorization = status }
  }

  private func accept(_ fix: CLLocation) {
    location = fix
    guard state == .recording, fix.horizontalAccuracy >= 0, fix.horizontalAccuracy <= Self.maximumAccuracy else {
      return
    }
    let point = Coord(fix.coordinate)
    if let last = track.last {
      let step = last.distance(to: point)
      guard step >= Self.minimumStep else {
        return
      }
      distance += step
    }
    track.append(point)
  }
}

/// Local reminders for golden hour at a viewpoint.
enum Reminders {
  static func remind(at date: Date, title: String, body: String) async -> Bool {
    let center = UNUserNotificationCenter.current()
    let granted = (try? await center.requestAuthorization(options: [.alert, .sound])) ?? false
    guard granted, date > Date() else {
      return false
    }
    let content = UNMutableNotificationContent()
    content.title = title
    content.body = body
    content.sound = .default
    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: date.timeIntervalSinceNow, repeats: false)
    let request = UNNotificationRequest(identifier: "\(title)-\(date.timeIntervalSince1970)", content: content, trigger: trigger)
    return (try? await center.add(request)) != nil
  }
}
