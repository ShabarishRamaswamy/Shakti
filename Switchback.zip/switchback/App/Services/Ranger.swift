import Foundation
import Observation
import SkyKit

/// Answers questions about a park from its bundled guide, its saved trails, today's light and the
/// latest alerts. Apple Intelligence words the answer on the phone; without it the best passage
/// from the guide is shown as is.
@Observable
final class Ranger {
  struct Answer: Identifiable, Equatable {
    let id = UUID()
    let question: String
    var text: String
    var source: String?
    var trailID: String?
    var isWritten: Bool
    var isThinking: Bool
  }

  private(set) var answers: [String: [Answer]] = [:]
  private let writer: Writer

  private struct Passage {
    let title: String
    let text: String
    let trailID: String?
    var words: [String: Int] = [:]
  }

  private static let stopWords: Set<String> = [
    "a", "an", "the", "is", "are", "to", "of", "in", "on", "for", "and", "or", "it", "can", "i", "my", "me",
    "we", "do", "does", "what", "where", "when", "how", "which", "there", "any", "with", "at", "be", "this", "that",
    "you", "your", "should", "best", "good", "get", "go", "some", "about", "from", "tonight", "today"
  ]
  private static let timeWords: Set<String> = ["sunset", "sunrise", "golden", "light", "dark", "moon", "tonight", "today", "morning", "evening", "time", "when"]
  private static let passageBudget = 2400
  private static let maxPassages = 4

  init(writer: Writer) {
    self.writer = writer
  }

  func conversation(for code: String) -> [Answer] {
    answers[code] ?? []
  }

  func ask(_ question: String, park: ParkSummary, guide: ParkGuide?, pack: ParkPack?, alerts: AlertSet?) async {
    let trimmed = question.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else {
      return
    }
    var answer = Answer(question: trimmed, text: "", source: nil, trailID: nil, isWritten: false, isThinking: true)
    answers[park.code, default: []].append(answer)
    let index = answers[park.code, default: []].count - 1

    let passages = Self.passages(park: park, guide: guide, pack: pack, alerts: alerts)
    let picked = Self.rank(passages, for: trimmed)
    answer.source = picked.first?.title
    answer.trailID = picked.first(where: { $0.trailID != nil })?.trailID

    let notes = picked.enumerated().map { "[\($0.offset + 1)] \($0.element.title): \($0.element.text)" }.joined(separator: "\n\n")
    let instructions = """
    You are a friendly, careful park ranger at \(park.fullName). Answer in two to four short sentences \
    using only the notes. Use the exact numbers and times from the notes. If the notes don't cover the \
    question, say you're not sure and suggest asking at a visitor center. Never invent trail names, \
    distances, rules or times. Put safety first.
    """
    if let written = await writer.write(instructions: instructions, prompt: "Notes:\n\(notes)\n\nQuestion: \(trimmed)") {
      answer.text = written
      answer.isWritten = true
    } else if let best = picked.first {
      answer.text = Self.excerpt(best.text)
    } else {
      answer.text = "The guide doesn't cover that. A visitor center can help."
    }
    answer.isThinking = false
    if answers[park.code]?.indices.contains(index) == true {
      answers[park.code]?[index] = answer
    }
  }

  func clear(_ code: String) {
    answers[code] = []
  }

  // MARK: Passages

  private static func passages(park: ParkSummary, guide: ParkGuide?, pack: ParkPack?, alerts: AlertSet?) -> [Passage] {
    var result: [Passage] = []
    func add(_ title: String, _ text: String, trail: String? = nil) {
      let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !clean.isEmpty else {
        return
      }
      result.append(Passage(title: title, text: clean, trailID: trail))
    }
    add("Today's light", todayText(park))
    if let guide {
      add("About \(guide.name)", guide.description)
      add("Weather", guide.weather)
      add("Getting there", guide.directions)
      add("Fees", guide.fees.map { "\($0.title): \($0.cost.map { "$\($0)" } ?? "") \($0.summary)" }.joined(separator: "\n"))
      add("Hours", guide.hours.map { "\($0.name): \($0.summary)" }.joined(separator: "\n"))
      for hike in guide.hikes {
        var text = [hike.summary, hike.body].filter { !$0.isEmpty }.joined(separator: " ")
        if !hike.duration.isEmpty {
          text += " Duration: \(hike.duration)."
        }
        if !hike.pets.isEmpty {
          text += " Pets: \(hike.pets)"
        }
        if !hike.accessibility.isEmpty {
          text += " Accessibility: \(hike.accessibility)"
        }
        add("Hike: \(hike.title)", text)
      }
      for item in guide.activities {
        add(item.title, [item.summary, item.body].filter { !$0.isEmpty }.joined(separator: " "))
      }
      for place in guide.places {
        add(place.title, [place.summary, place.body].filter { !$0.isEmpty }.joined(separator: " "))
      }
      for center in guide.visitorCenters {
        add("Visitor center: \(center.name)", "\(center.summary) \(center.directions) \(center.phone.map { "Phone \($0)." } ?? "")")
      }
      for camp in guide.campgrounds {
        add("Campground: \(camp.name)", "\(camp.summary) \(camp.sites.map { "\($0) sites." } ?? "") \(camp.reservation)")
      }
    }
    for trail in pack?.trails ?? [] {
      var facts = ["\(trail.name): \(Units.miles(trail.length)) of mapped trail"]
      facts.append(trail.isLoop ? "a loop" : "about \(Units.miles(trail.roundTrip)) round trip")
      if let climb = trail.climb {
        facts.append("about \(Units.feet(climb)) of climbing one way")
      }
      if let top = trail.highest {
        facts.append("highest point \(Units.feet(top))")
      }
      facts.append("most people take \(Units.hours(trail.estimatedHours))")
      if trail.isSeasonal {
        facts.append("seasonal")
      }
      add("Trail: \(trail.name)", facts.joined(separator: ", ") + ".", trail: trail.id)
    }
    for alert in alerts?.alerts ?? [] {
      add("Alert: \(alert.title)", "\(alert.category). \(alert.summary)")
    }
    return result.map { passage in
      var indexed = passage
      for word in words(passage.title + " " + passage.text) {
        indexed.words[word, default: 0] += 1
      }
      return indexed
    }
  }

  private static func rank(_ passages: [Passage], for question: String) -> [Passage] {
    let query = words(question).filter { !stopWords.contains($0) }
    let asksTime = !Set(words(question)).isDisjoint(with: timeWords)
    let documentCount = Double(max(1, passages.count))
    let scored = passages.map { passage -> (Passage, Double) in
      var score = 0.0
      let titleWords = Set(words(passage.title))
      for word in query {
        let frequency = Double(passage.words[word] ?? 0)
        guard frequency > 0 else {
          continue
        }
        let spread = Double(passages.filter { $0.words[word] != nil }.count)
        let rarity = log(documentCount / spread) + 1
        score += (min(frequency, 4) + (titleWords.contains(word) ? 3 : 0)) * rarity
      }
      if asksTime, passage.title == "Today's light" {
        score += 6
      }
      return (passage, score)
    }
    var budget = passageBudget
    var picked: [Passage] = []
    for (passage, score) in scored.sorted(by: { $0.1 > $1.1 }) where score > 0 && picked.count < maxPassages {
      let trimmed = Passage(title: passage.title, text: String(passage.text.prefix(budget)), trailID: passage.trailID)
      picked.append(trimmed)
      budget -= trimmed.text.count
      if budget < 200 {
        break
      }
    }
    return picked
  }

  private static func words(_ text: String) -> [String] {
    text.lowercased()
      .components(separatedBy: CharacterSet.alphanumerics.inverted)
      .filter { $0.count > 1 }
      .map { $0.count > 4 && $0.hasSuffix("s") ? String($0.dropLast()) : $0 }
  }

  private static func excerpt(_ text: String) -> String {
    guard text.count > 320 else {
      return text
    }
    let cut = text.prefix(320)
    return (cut.range(of: ". ", options: .backwards).map { String(cut[..<$0.upperBound]) } ?? String(cut) + "…")
  }

  static func todayText(_ park: ParkSummary) -> String {
    guard let lat = park.lat, let lon = park.lon else {
      return ""
    }
    let day = DaylightCalculator.day(containing: Date(), latitude: lat, longitude: lon, timeZone: park.zone)
    let time = { (date: Date?) in date.map { $0.formatted(Date.FormatStyle(date: .omitted, time: .shortened, timeZone: park.zone)) } ?? "none" }
    let now = Date().formatted(Date.FormatStyle(date: .abbreviated, time: .shortened, timeZone: park.zone))
    return "It is now \(now) in the park. Sunrise \(time(day.sunrise)), sunset \(time(day.sunset)). Evening golden hour \(time(day.eveningGoldenStart)) to \(time(day.eveningGoldenEnd)). Last light \(time(day.lastLight)). Moon \(Int((day.moonIllumination * 100).rounded()))% lit, rises \(time(day.moonrise)), sets \(time(day.moonset))."
  }
}
