import Foundation
import FoundationModels
import Network
import Observation

/// Apple's on-device model. Nothing leaves the phone; every caller has plain wording to fall back on.
@Observable
final class Writer {
  private(set) var isAvailable = false
  private(set) var statusText = ""
  private var isBusy = false

  init() {
    refresh()
  }

  func refresh() {
    switch SystemLanguageModel.default.availability {
    case .available:
      isAvailable = true
      statusText = "Answers on this iPhone"
    case .unavailable(.deviceNotEligible):
      isAvailable = false
      statusText = "This iPhone can't run Apple Intelligence; answers come from the guide"
    case .unavailable(.appleIntelligenceNotEnabled):
      isAvailable = false
      statusText = "Turn on Apple Intelligence for written answers"
    case .unavailable(.modelNotReady):
      isAvailable = false
      statusText = "Apple Intelligence is still downloading"
    case .unavailable:
      isAvailable = false
      statusText = "Apple Intelligence isn't available"
    }
  }

  func write(instructions: String, prompt: String, maxTokens: Int = 220) async -> String? {
    guard isAvailable else {
      return nil
    }
    while isBusy {
      try? await Task.sleep(for: .milliseconds(120))
    }
    isBusy = true
    defer { isBusy = false }
    do {
      let session = LanguageModelSession(instructions: instructions)
      let response = try await session.respond(to: prompt, options: GenerationOptions(temperature: 0.4, maximumResponseTokens: maxTokens))
      let text = response.content.trimmingCharacters(in: .whitespacesAndNewlines.union(CharacterSet(charactersIn: "\"“”")))
      return text.isEmpty ? nil : text
    } catch {
      return nil
    }
  }
}

/// Whether there's a network connection right now.
@Observable
final class Connectivity {
  private(set) var isOnline = true
  private let monitor = NWPathMonitor()

  init() {
    monitor.pathUpdateHandler = { [weak self] path in
      let online = path.status == .satisfied
      Task { @MainActor in self?.isOnline = online }
    }
    monitor.start(queue: DispatchQueue(label: "connectivity"))
  }
}
