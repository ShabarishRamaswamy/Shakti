import SwiftUI

/// Park-poster colours and type, from the Switchback design.
nonisolated enum Palette {
  static let paper = Color(hex: 0xF2EEE4)
  static let card = Color(hex: 0xFBF9F4)
  static let ink = Color(hex: 0x1E2B24)
  static let muted = Color(hex: 0x56615A)
  static let forest = Color(hex: 0x1F4D3A)
  static let deepForest = Color(hex: 0x163A2C)
  static let rust = Color(hex: 0xC24A1F)
  static let sand = Color(hex: 0xF2E3C9)
  static let gold = Color(hex: 0xFBE3B0)
  static let amber = Color(hex: 0xE9B85E)
  static let water = Color(hex: 0x2E6E8C)
  static let olive = Color(hex: 0x6E7F3E)
  static let line = Color(hex: 0x1E2B24).opacity(0.12)
}

enum Typeface {
  /// The condensed poster face used for park and trail names.
  static func poster(_ size: CGFloat, _ weight: Font.Weight = .heavy) -> Font {
    .system(size: size, weight: weight).width(.compressed)
  }

  static func label(_ size: CGFloat, _ weight: Font.Weight = .bold) -> Font {
    .system(size: size, weight: weight).width(.condensed)
  }

  static func body(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
    .system(size: size, weight: weight)
  }
}

nonisolated extension Color {
  init(hex: UInt32) {
    self.init(
      .sRGB,
      red: Double((hex >> 16) & 0xFF) / 255,
      green: Double((hex >> 8) & 0xFF) / 255,
      blue: Double(hex & 0xFF) / 255
    )
  }
}

// MARK: Shared pieces

struct Eyebrow: View {
  let text: String
  var color: Color = Palette.muted

  var body: some View {
    Text(text.uppercased())
      .font(Typeface.body(12, .bold))
      .tracking(1.4)
      .foregroundStyle(color)
      .accessibilityAddTraits(.isHeader)
  }
}

struct Chip: View {
  let text: String
  var systemImage: String?
  var foreground: Color = Palette.forest
  var background: Color = Palette.card

  var body: some View {
    HStack(spacing: 5) {
      if let systemImage {
        Image(systemName: systemImage).font(.system(size: 11, weight: .bold))
      }
      Text(text).font(Typeface.body(12, .bold))
    }
    .foregroundStyle(foreground)
    .padding(.horizontal, 10)
    .frame(height: 26)
    .background(Capsule().fill(background))
  }
}

struct Card<Content: View>: View {
  @ViewBuilder let content: Content

  var body: some View {
    content
      .padding(16)
      .frame(maxWidth: .infinity, alignment: .leading)
      .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
      .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Palette.line, lineWidth: 1))
  }
}

struct PrimaryButtonStyle: ButtonStyle {
  var color: Color = Palette.forest

  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .font(Typeface.body(16, .bold))
      .foregroundStyle(Palette.card)
      .frame(maxWidth: .infinity, minHeight: 52)
      .background(Capsule().fill(color))
      .opacity(configuration.isPressed ? 0.85 : 1)
  }
}

struct SecondaryButtonStyle: ButtonStyle {
  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .font(Typeface.body(16, .bold))
      .foregroundStyle(Palette.forest)
      .frame(maxWidth: .infinity, minHeight: 52)
      .background(Capsule().fill(Palette.card))
      .overlay(Capsule().stroke(Palette.forest.opacity(0.35), lineWidth: 1.5))
      .opacity(configuration.isPressed ? 0.8 : 1)
  }
}

struct RoundIconButtonStyle: ButtonStyle {
  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .font(.system(size: 17, weight: .semibold))
      .foregroundStyle(Palette.ink)
      .frame(width: 44, height: 44)
      .background(Circle().fill(Palette.card))
      .overlay(Circle().stroke(Palette.line, lineWidth: 1))
      .contentShape(Circle())
      .opacity(configuration.isPressed ? 0.7 : 1)
  }
}

/// The switchback mark from the logo: a trail zig-zagging up a slope.
struct SwitchbackMark: Shape {
  nonisolated func path(in rect: CGRect) -> Path {
    let w = rect.width
    let h = rect.height
    var path = Path()
    path.move(to: CGPoint(x: rect.minX + w * 0.17, y: rect.minY + h * 0.83))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.42, y: rect.minY + h * 0.83))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.29, y: rect.minY + h * 0.62))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.58, y: rect.minY + h * 0.62))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.46, y: rect.minY + h * 0.42))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.71, y: rect.minY + h * 0.42))
    path.addLine(to: CGPoint(x: rect.minX + w * 0.58, y: rect.minY + h * 0.21))
    return path
  }
}

/// A simple mountain, for park tiles without a photo.
struct MountainGlyph: Shape {
  nonisolated func path(in rect: CGRect) -> Path {
    var path = Path()
    path.move(to: CGPoint(x: rect.minX + rect.width * 0.12, y: rect.maxY - rect.height * 0.2))
    path.addLine(to: CGPoint(x: rect.minX + rect.width * 0.4, y: rect.minY + rect.height * 0.32))
    path.addLine(to: CGPoint(x: rect.minX + rect.width * 0.56, y: rect.minY + rect.height * 0.58))
    path.addLine(to: CGPoint(x: rect.minX + rect.width * 0.66, y: rect.minY + rect.height * 0.42))
    path.addLine(to: CGPoint(x: rect.maxX - rect.width * 0.12, y: rect.maxY - rect.height * 0.2))
    path.closeSubpath()
    return path
  }
}

struct ParkBadge: View {
  let park: ParkSummary
  var side: CGFloat = 38

  var body: some View {
    MountainGlyph()
      .fill(Palette.card)
      .padding(side * 0.18)
      .frame(width: side, height: side)
      .background(RoundedRectangle(cornerRadius: side * 0.29, style: .continuous).fill(park.tint))
      .accessibilityHidden(true)
  }
}
