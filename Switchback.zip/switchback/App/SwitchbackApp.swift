import SwiftUI

@main
struct SwitchbackApp: App {
  @State private var app = AppModel()

  var body: some Scene {
    WindowGroup {
      RootView()
        .environment(app)
        .tint(Palette.forest)
    }
    .modelContainer(app.container)
  }
}

struct RootView: View {
  @Environment(AppModel.self) private var app

  var body: some View {
    if app.hasOnboarded {
      tabs
    } else {
      WelcomeView()
    }
  }

  private var tabs: some View {
    @Bindable var app = app
    return ZStack(alignment: .bottom) {
      Group {
        switch app.tab {
        case .parks:
          NavigationStack(path: $app.parksPath) {
            ParksHomeView().routes()
          }
        case .map:
          NavigationStack(path: $app.mapPath) {
            MapScreen().routes()
          }
        case .ranger:
          NavigationStack {
            RangerView()
          }
        case .journal:
          NavigationStack(path: $app.journalPath) {
            JournalView().routes()
          }
        }
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity)
      TabBar()
    }
    .background(Palette.paper)
  }
}

private struct Routes: ViewModifier {
  func body(content: Content) -> some View {
    content.navigationDestination(for: Route.self) { route in
      switch route {
      case .park(let code): ParkView(code: code)
      case .trail(let park, let trail): TrailView(parkCode: park, trailID: trail)
      case .viewpoint(let park, let place): ViewpointView(parkCode: park, placeID: place)
      case .explore(let query): ExploreView(initialQuery: query)
      case .download(let code): DownloadView(code: code)
      case .hike: HikeView()
      case .safety: SafetyView()
      case .postcard(let id): PostcardView(recordID: id)
      }
    }
  }
}

extension View {
  func routes() -> some View {
    modifier(Routes())
  }
}

struct TabBar: View {
  @Environment(AppModel.self) private var app

  private struct Item {
    let tab: AppModel.Tab
    let title: String
    let symbol: String
  }

  private let items = [
    Item(tab: .parks, title: "Parks", symbol: "mountain.2"),
    Item(tab: .map, title: "Map", symbol: "map"),
    Item(tab: .ranger, title: "Ranger", symbol: "bubble.left"),
    Item(tab: .journal, title: "Journal", symbol: "book.closed")
  ]

  var body: some View {
    HStack(spacing: 4) {
      ForEach(items, id: \.title) { item in
        let selected = app.tab == item.tab
        Button {
          if app.tab == item.tab {
            pop(item.tab)
          }
          app.tab = item.tab
        } label: {
          VStack(spacing: 3) {
            Image(systemName: item.symbol).font(.system(size: 19, weight: .semibold))
            Text(item.title).font(Typeface.body(11, selected ? .bold : .semibold))
          }
          .foregroundStyle(selected ? Palette.forest : Palette.muted)
          .frame(maxWidth: .infinity, minHeight: 52)
          .background(Capsule().fill(selected ? Palette.forest.opacity(0.1) : .clear))
          .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
      }
    }
    .padding(6)
    .background(Capsule().fill(Palette.card.opacity(0.97)))
    .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
    .shadow(color: Palette.ink.opacity(0.1), radius: 12, y: 6)
    .padding(.horizontal, 16)
    .padding(.bottom, 4)
  }

  private func pop(_ tab: AppModel.Tab) {
    switch tab {
    case .parks: app.parksPath = []
    case .map: app.mapPath = app.recorder.isActive ? [.hike] : []
    case .journal: app.journalPath = []
    case .ranger: break
    }
  }
}
