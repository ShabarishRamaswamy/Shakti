import CoreLocation
import SwiftUI

nonisolated struct ParkImage: Codable, Hashable, Sendable {
  let url: String?
  let alt: String?
  let credit: String?
}

/// One park in the bundled index.
nonisolated struct ParkSummary: Codable, Identifiable, Hashable, Sendable {
  let code: String
  let name: String
  let fullName: String
  let designation: String
  let states: String
  let timeZone: String?
  let lat: Double?
  let lon: Double?
  let summary: String
  let categories: [String]
  let image: ParkImage?
  let hikeCount: Int
  let placeCount: Int

  var id: String { code }

  var zone: TimeZone {
    timeZone.flatMap(TimeZone.init(identifier:)) ?? .current
  }

  var coordinate: CLLocationCoordinate2D? {
    guard let lat, let lon else {
      return nil
    }
    return CLLocationCoordinate2D(latitude: lat, longitude: lon)
  }

  var stateNames: String {
    states.split(separator: ",").map { StateNames.name(for: String($0)) }.joined(separator: ", ")
  }

  /// A colour for the park's badge, from what kind of place it is.
  var tint: Color {
    switch categories.first {
    case "desert": Color(hex: 0xC2552B)
    case "coast": Color(hex: 0x2E6E8C)
    case "forest": Palette.olive
    case "volcanoes": Color(hex: 0x8A3412)
    case "caves": Color(hex: 0x56615A)
    case "mountains": Palette.forest
    default: Color(hex: 0xB5651D)
    }
  }
}

nonisolated struct GuideItem: Codable, Hashable, Sendable, Identifiable {
  let id: String?
  let title: String
  let summary: String
  let body: String
  let duration: String
  let season: [String]
  let timeOfDay: [String]
  let pets: String
  let fees: Bool
  let reservation: Bool
  let accessibility: String
  let activities: [String]
  let lat: Double?
  let lon: Double?
  let image: ParkImage?

  var stableID: String { id ?? title }
}

nonisolated struct Place: Codable, Hashable, Sendable, Identifiable {
  let id: String?
  let title: String
  let summary: String
  let body: String
  let tags: [String]
  let lat: Double?
  let lon: Double?
  let image: ParkImage?

  var coordinate: CLLocationCoordinate2D? {
    guard let lat, let lon else {
      return nil
    }
    return CLLocationCoordinate2D(latitude: lat, longitude: lon)
  }

  /// Overlooks and viewpoints, the places worth catching the light from.
  var isViewpoint: Bool {
    let words = ["overlook", "view", "vista", "point", "scenic", "summit", "lookout", "sunset", "sunrise"]
    let haystack = (title + " " + tags.joined(separator: " ")).lowercased()
    return words.contains(where: haystack.contains)
  }
}

nonisolated struct VisitorCenter: Codable, Hashable, Sendable {
  let name: String
  let summary: String
  let directions: String
  let lat: Double?
  let lon: Double?
  let phone: String?
}

nonisolated struct Campground: Codable, Hashable, Sendable {
  let name: String
  let summary: String
  let reservation: String
  let sites: String?
  let lat: Double?
  let lon: Double?
}

nonisolated struct Fee: Codable, Hashable, Sendable {
  let title: String
  let cost: String?
  let summary: String
}

nonisolated struct OpeningHours: Codable, Hashable, Sendable {
  let name: String
  let summary: String
}

/// The full bundled guide for one park.
nonisolated struct ParkGuide: Codable, Sendable {
  let code: String
  let name: String
  let fullName: String
  let states: String
  let description: String
  let weather: String
  let directions: String
  let fees: [Fee]
  let hours: [OpeningHours]
  let phone: String?
  let hikes: [GuideItem]
  let activities: [GuideItem]
  let places: [Place]
  let visitorCenters: [VisitorCenter]
  let campgrounds: [Campground]

  var viewpoints: [Place] {
    places.filter { $0.isViewpoint && $0.coordinate != nil }
  }
}

nonisolated enum ParkCategory: String, CaseIterable, Identifiable, Sendable {
  case mountains
  case desert
  case coast
  case forest
  case volcanoes
  case caves

  var id: String { rawValue }
  var title: String { rawValue.capitalized }
}

nonisolated enum StateNames {
  private static let names: [String: String] = [
    "AK": "Alaska", "AR": "Arkansas", "AS": "American Samoa", "AZ": "Arizona", "CA": "California", "CO": "Colorado",
    "FL": "Florida", "HI": "Hawaii", "ID": "Idaho", "IN": "Indiana", "KY": "Kentucky", "ME": "Maine", "MI": "Michigan",
    "MN": "Minnesota", "MO": "Missouri", "MT": "Montana", "NC": "North Carolina", "ND": "North Dakota", "NM": "New Mexico",
    "NV": "Nevada", "OH": "Ohio", "OR": "Oregon", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee",
    "TX": "Texas", "UT": "Utah", "VA": "Virginia", "VI": "U.S. Virgin Islands", "WA": "Washington", "WV": "West Virginia",
    "WY": "Wyoming"
  ]

  static func name(for code: String) -> String {
    names[code.trimmingCharacters(in: .whitespaces)] ?? code
  }
}
