import Foundation
import SwiftData

/// A recorded hike. The track is kept as JSON so it travels with the record.
@Model
final class HikeRecord {
  var parkCode: String
  var parkName: String
  var trailName: String
  var startedAt: Date
  var endedAt: Date
  var distance: Double
  var climb: Double
  var movingSeconds: Double
  var trackData: Data
  var caption: String?
  @Attribute(.externalStorage) var photo: Data?

  init(parkCode: String, parkName: String, trailName: String, startedAt: Date, endedAt: Date, distance: Double, climb: Double, movingSeconds: Double, track: [Coord]) {
    self.parkCode = parkCode
    self.parkName = parkName
    self.trailName = trailName
    self.startedAt = startedAt
    self.endedAt = endedAt
    self.distance = distance
    self.climb = climb
    self.movingSeconds = movingSeconds
    self.trackData = (try? JSONEncoder().encode(track)) ?? Data()
  }

  var track: [Coord] {
    (try? JSONDecoder().decode([Coord].self, from: trackData)) ?? []
  }
}

nonisolated enum Storage {
  static let schema = Schema([HikeRecord.self])

  static func makeContainer() -> ModelContainer {
    do {
      return try ModelContainer(for: schema, configurations: ModelConfiguration(schema: schema))
    } catch {
      return try! ModelContainer(for: schema, configurations: ModelConfiguration(schema: schema, isStoredInMemoryOnly: true))
    }
  }

  /// Where a park's download lives: trails, alerts and map tiles.
  static func parkFolder(_ code: String) -> URL {
    let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
    let url = base.appending(path: "Parks/\(code)", directoryHint: .isDirectory)
    try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  static func tileURL(park code: String, z: Int, x: Int, y: Int) -> URL {
    parkFolder(code).appending(path: "tiles/\(z)/\(x)/\(y).jpg")
  }
}
