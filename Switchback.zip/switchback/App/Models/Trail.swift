import CoreLocation
import Foundation

nonisolated struct Coord: Codable, Hashable, Sendable {
  let lat: Double
  let lon: Double

  init(_ lat: Double, _ lon: Double) {
    self.lat = lat
    self.lon = lon
  }

  init(_ coordinate: CLLocationCoordinate2D) {
    lat = coordinate.latitude
    lon = coordinate.longitude
  }

  var coordinate: CLLocationCoordinate2D {
    CLLocationCoordinate2D(latitude: lat, longitude: lon)
  }

  func distance(to other: Coord) -> Double {
    Geo.distance(self, other)
  }
}

nonisolated struct ProfilePoint: Codable, Hashable, Sendable {
  /// Metres along the trail from its start.
  let distance: Double
  let elevation: Double
}

/// A named trail from the NPS Public Trails data, its pieces joined where they meet.
nonisolated struct Trail: Codable, Hashable, Sendable, Identifiable {
  let id: String
  let name: String
  /// Every mapped piece, for drawing.
  let segments: [[Coord]]
  /// The longest run of joined pieces, start to end, for the profile and the walk.
  private(set) var path: [Coord]
  /// Length of all mapped trail with this name, in metres.
  let length: Double
  /// The length of the hike itself: the main route when the name also covers spurs and side trails.
  let routeLength: Double
  let isLoop: Bool
  let surface: String?
  let isSeasonal: Bool
  private(set) var profile: [ProfilePoint]?

  /// Stores elevations, turning the trail round if needed so it starts at its low end, where
  /// most hikes begin.
  mutating func setProfile(_ points: [ProfilePoint]) {
    guard let first = points.first, let last = points.last, first.elevation > last.elevation + 10, !isLoop else {
      profile = points
      return
    }
    let total = last.distance
    path.reverse()
    profile = points.reversed().map { ProfilePoint(distance: total - $0.distance, elevation: $0.elevation) }
  }

  var trailhead: Coord? { path.first }
  var far: Coord? { isLoop ? nil : path.last }

  /// Metres climbed walking the path in its direction.
  var climb: Double? {
    guard let profile, profile.count > 1 else {
      return nil
    }
    return zip(profile, profile.dropFirst()).reduce(0) { $0 + max(0, $1.1.elevation - $1.0.elevation) }
  }

  var highest: Double? { profile?.map(\.elevation).max() }

  /// Out-and-back distance unless it loops.
  var roundTrip: Double {
    isLoop ? routeLength : routeLength * 2
  }

  /// Walking time by Naismith's rule, a little slower to suit most park visitors.
  var estimatedHours: ClosedRange<Double> {
    let hours = roundTrip / 1609.34 / 2.5 + (climb ?? 0) * 3.28084 / 2000
    let low = max(0.25, (hours * 0.8 * 4).rounded() / 4)
    let high = max(low + 0.25, (hours * 1.3 * 4).rounded() / 4)
    return low...high
  }
}

/// A distance the park guide states for a hike, such as "2.2 miles round trip".
nonisolated struct GuideDistance: Sendable {
  let meters: Double
  let isLoop: Bool

  private static let patterns = [
    #"(\d+(?:\.\d+)?)[- ]?(?:mile|mi)s?\b[^.;]{0,24}?(round[- ]?trip|loop|one[- ]way|out[- ]and[- ]back)"#,
    #"(round[- ]?trip|loop|one[- ]way)[^.;]{0,16}?(\d+(?:\.\d+)?)[- ]?(?:mile|mi)s?\b"#
  ]

  static func parse(_ text: String) -> GuideDistance? {
    let lower = text.lowercased()
    for (index, pattern) in patterns.enumerated() {
      guard let regex = try? NSRegularExpression(pattern: pattern),
            let match = regex.firstMatch(in: lower, range: NSRange(lower.startIndex..., in: lower)),
            let first = Range(match.range(at: 1), in: lower),
            let second = Range(match.range(at: 2), in: lower) else {
        continue
      }
      let number = String(index == 0 ? lower[first] : lower[second])
      let kind = String(index == 0 ? lower[second] : lower[first])
      guard let miles = Double(number), miles > 0, miles < 60 else {
        continue
      }
      let oneWay = kind.contains("one")
      return GuideDistance(meters: miles * 1609.34 * (oneWay ? 2 : 1), isLoop: kind.contains("loop"))
    }
    return nil
  }
}

nonisolated struct BBox: Codable, Hashable, Sendable {
  var minLat: Double
  var minLon: Double
  var maxLat: Double
  var maxLon: Double

  init(minLat: Double, minLon: Double, maxLat: Double, maxLon: Double) {
    self.minLat = minLat
    self.minLon = minLon
    self.maxLat = maxLat
    self.maxLon = maxLon
  }

  init?(_ coords: [Coord]) {
    guard let first = coords.first else {
      return nil
    }
    self.init(minLat: first.lat, minLon: first.lon, maxLat: first.lat, maxLon: first.lon)
    for c in coords {
      minLat = min(minLat, c.lat)
      maxLat = max(maxLat, c.lat)
      minLon = min(minLon, c.lon)
      maxLon = max(maxLon, c.lon)
    }
  }

  func padded(by fraction: Double) -> BBox {
    let dLat = max((maxLat - minLat) * fraction, 0.01)
    let dLon = max((maxLon - minLon) * fraction, 0.01)
    return BBox(minLat: minLat - dLat, minLon: minLon - dLon, maxLat: maxLat + dLat, maxLon: maxLon + dLon)
  }

  var center: Coord {
    Coord((minLat + maxLat) / 2, (minLon + maxLon) / 2)
  }
}

/// What a park download saved.
nonisolated struct ParkPack: Codable, Sendable {
  let code: String
  let trails: [Trail]
  let bbox: BBox
  let minZoom: Int
  let maxZoom: Int
  let tileCount: Int
  let savedAt: Date
}

nonisolated struct ParkAlert: Codable, Hashable, Sendable, Identifiable {
  let id: String
  let title: String
  let summary: String
  let category: String
}

nonisolated struct AlertSet: Codable, Sendable {
  let alerts: [ParkAlert]
  let fetchedAt: Date
}

nonisolated enum Geo {
  static func distance(_ a: Coord, _ b: Coord) -> Double {
    let r = 6_371_000.0
    let dLat = (b.lat - a.lat) * .pi / 180
    let dLon = (b.lon - a.lon) * .pi / 180
    let h = sin(dLat / 2) * sin(dLat / 2) + cos(a.lat * .pi / 180) * cos(b.lat * .pi / 180) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * r * asin(min(1, sqrt(h)))
  }

  static func length(_ line: [Coord]) -> Double {
    zip(line, line.dropFirst()).reduce(0) { $0 + distance($1.0, $1.1) }
  }

  /// Points spaced evenly along a line, with their distance from its start.
  static func resample(_ line: [Coord], count: Int) -> [(Coord, Double)] {
    let total = length(line)
    guard line.count > 1, total > 0, count > 1 else {
      return line.first.map { [($0, 0)] } ?? []
    }
    var result: [(Coord, Double)] = []
    var walked = 0.0
    var index = 0
    for step in 0..<count {
      let target = total * Double(step) / Double(count - 1)
      while index < line.count - 2, walked + distance(line[index], line[index + 1]) < target {
        walked += distance(line[index], line[index + 1])
        index += 1
      }
      let a = line[index]
      let b = line[index + 1]
      let piece = distance(a, b)
      let t = piece > 0 ? min(1, max(0, (target - walked) / piece)) : 0
      result.append((Coord(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t), target))
    }
    return result
  }

  /// Drops points closer than `tolerance` metres to the line between their neighbours.
  static func simplify(_ line: [Coord], tolerance: Double) -> [Coord] {
    guard line.count > 2 else {
      return line
    }
    var keep = [Bool](repeating: false, count: line.count)
    keep[0] = true
    keep[line.count - 1] = true
    var stack = [(0, line.count - 1)]
    while let (start, end) = stack.popLast() {
      var farthest = 0.0
      var index = start
      for i in (start + 1)..<end {
        let d = offset(line[i], from: line[start], to: line[end])
        if d > farthest {
          farthest = d
          index = i
        }
      }
      if farthest > tolerance {
        keep[index] = true
        stack.append((start, index))
        stack.append((index, end))
      }
    }
    return line.indices.filter { keep[$0] }.map { line[$0] }
  }

  private static func offset(_ p: Coord, from a: Coord, to b: Coord) -> Double {
    let scale = cos(a.lat * .pi / 180) * 111_320
    let ax = a.lon * scale, ay = a.lat * 110_540
    let bx = b.lon * scale, by = b.lat * 110_540
    let px = p.lon * scale, py = p.lat * 110_540
    let dx = bx - ax, dy = by - ay
    let lengthSquared = dx * dx + dy * dy
    guard lengthSquared > 0 else {
      return hypot(px - ax, py - ay)
    }
    let t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / lengthSquared))
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
  }
}

nonisolated enum Units {
  static func miles(_ meters: Double, digits: Int = 1) -> String {
    let miles = meters / 1609.34
    return String(format: "%.\(digits)f mi", miles)
  }

  static func feet(_ meters: Double) -> String {
    let feet = Int((meters * 3.28084).rounded())
    return "\(feet.formatted()) ft"
  }

  static func hours(_ range: ClosedRange<Double>) -> String {
    if range.upperBound <= 1 {
      let low = Int((range.lowerBound * 60 / 5).rounded()) * 5
      let high = max(low + 5, Int((range.upperBound * 60 / 5).rounded()) * 5)
      return "\(low)–\(high) min"
    }
    let halves = { (value: Double) -> String in
      let rounded = max(0.5, (value * 2).rounded() / 2)
      return rounded.truncatingRemainder(dividingBy: 1) == 0 ? "\(Int(rounded))" : String(format: "%.1f", rounded)
    }
    return "\(halves(range.lowerBound))–\(halves(range.upperBound)) hr"
  }

  static func duration(_ seconds: TimeInterval) -> String {
    let total = Int(seconds)
    let h = total / 3600
    let m = (total % 3600) / 60
    return h > 0 ? "\(h) h \(m) m" : "\(m) min"
  }

  static func clock(_ seconds: TimeInterval) -> String {
    let total = Int(seconds)
    let h = total / 3600
    let m = (total % 3600) / 60
    let s = total % 60
    return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
  }
}
