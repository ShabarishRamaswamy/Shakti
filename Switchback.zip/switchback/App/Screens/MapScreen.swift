import MapKit
import SwiftUI

/// USGS topo tiles: from disk when the park is saved, from the network otherwise.
nonisolated final class TopoOverlay: MKTileOverlay {
  private let code: String?

  init(park code: String?, maxZoom: Int) {
    self.code = code
    super.init(urlTemplate: nil)
    maximumZ = maxZoom
    canReplaceMapContent = false
  }

  override func loadTile(at path: MKTileOverlayPath, result: @escaping (Data?, (any Error)?) -> Void) {
    if let code, let data = try? Data(contentsOf: Storage.tileURL(park: code, z: path.z, x: path.x, y: path.y)) {
      result(data, nil)
      return
    }
    URLSession.shared.dataTask(with: TileSource.url(z: path.z, x: path.x, y: path.y)) { data, response, error in
      let ok = (response as? HTTPURLResponse)?.statusCode == 200
      result(ok ? data : nil, error)
    }.resume()
  }
}

nonisolated final class TrailLine: MKPolyline {
  var trailID = ""
  var isHighlight = false
  var isTrack = false
}

final class PlacePin: NSObject, MKAnnotation {
  let coordinate: CLLocationCoordinate2D
  let title: String?
  let placeID: String

  init(_ place: Place) {
    coordinate = place.coordinate ?? CLLocationCoordinate2D()
    title = place.title
    placeID = place.id ?? place.title
  }
}

struct ParkMapView: UIViewRepresentable {
  let park: ParkSummary
  let pack: ParkPack?
  let viewpoints: [Place]
  @Binding var selectedTrail: String?
  var focusTrail: String?
  var track: [Coord]
  var onPlace: (String) -> Void

  func makeCoordinator() -> Coordinator {
    Coordinator(self)
  }

  func makeUIView(context: Context) -> MKMapView {
    let map = MKMapView()
    map.delegate = context.coordinator
    map.showsUserLocation = true
    map.pointOfInterestFilter = .excludingAll
    map.showsCompass = true
    map.showsScale = true
    map.addOverlay(TopoOverlay(park: pack == nil ? nil : park.code, maxZoom: pack?.maxZoom ?? 16), level: .aboveLabels)
    context.coordinator.addTrails(to: map)
    map.addAnnotations(viewpoints.filter { $0.coordinate != nil }.map(PlacePin.init))
    let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped(_:)))
    map.addGestureRecognizer(tap)
    if let box = pack?.bbox {
      map.setRegion(region(box), animated: false)
    } else if let center = park.coordinate {
      map.setRegion(MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.35, longitudeDelta: 0.35)), animated: false)
    }
    return map
  }

  func updateUIView(_ map: MKMapView, context: Context) {
    context.coordinator.parent = self
    context.coordinator.highlight(selectedTrail, on: map)
    context.coordinator.drawTrack(track, on: map)
    if let focusTrail, context.coordinator.focused != focusTrail, let trail = pack?.trails.first(where: { $0.id == focusTrail }), let box = BBox(trail.segments.flatMap { $0 }) {
      context.coordinator.focused = focusTrail
      map.setRegion(region(box.padded(by: 0.3)), animated: true)
    }
  }

  private func region(_ box: BBox) -> MKCoordinateRegion {
    MKCoordinateRegion(
      center: box.center.coordinate,
      span: MKCoordinateSpan(latitudeDelta: max(0.01, box.maxLat - box.minLat), longitudeDelta: max(0.01, box.maxLon - box.minLon))
    )
  }

  final class Coordinator: NSObject, MKMapViewDelegate {
    var parent: ParkMapView
    var focused: String?
    private var highlighted: String?
    private var highlightLines: [TrailLine] = []
    private var trackLine: TrailLine?
    private var trackCount = 0
    /// Every drawn piece, in map points, for finding the trail under a tap.
    private var pieces: [(id: String, points: [MKMapPoint])] = []

    init(_ parent: ParkMapView) {
      self.parent = parent
    }

    func addTrails(to map: MKMapView) {
      for trail in parent.pack?.trails ?? [] {
        for segment in trail.segments {
          let coords = segment.map(\.coordinate)
          let line = TrailLine(coordinates: coords, count: coords.count)
          line.trailID = trail.id
          map.addOverlay(line, level: .aboveLabels)
          pieces.append((trail.id, coords.map(MKMapPoint.init)))
        }
      }
    }

    func highlight(_ id: String?, on map: MKMapView) {
      guard id != highlighted else {
        return
      }
      highlighted = id
      map.removeOverlays(highlightLines)
      highlightLines = []
      guard let id, let trail = parent.pack?.trails.first(where: { $0.id == id }) else {
        return
      }
      for segment in trail.segments {
        let coords = segment.map(\.coordinate)
        let line = TrailLine(coordinates: coords, count: coords.count)
        line.trailID = id
        line.isHighlight = true
        highlightLines.append(line)
      }
      map.addOverlays(highlightLines, level: .aboveLabels)
    }

    func drawTrack(_ track: [Coord], on map: MKMapView) {
      guard track.count != trackCount else {
        return
      }
      trackCount = track.count
      if let trackLine {
        map.removeOverlay(trackLine)
      }
      guard track.count > 1 else {
        trackLine = nil
        return
      }
      let coords = track.map(\.coordinate)
      let line = TrailLine(coordinates: coords, count: coords.count)
      line.isTrack = true
      trackLine = line
      map.addOverlay(line, level: .aboveLabels)
    }

    @objc func tapped(_ gesture: UITapGestureRecognizer) {
      guard let map = gesture.view as? MKMapView else {
        return
      }
      let point = MKMapPoint(map.convert(gesture.location(in: map), toCoordinateFrom: map))
      let tolerance = 22 * map.visibleMapRect.size.width / Double(max(1, map.bounds.width))
      var best: (String, Double)?
      for piece in pieces {
        for (a, b) in zip(piece.points, piece.points.dropFirst()) {
          let d = Self.distance(point, a, b)
          if d < tolerance, d < (best?.1 ?? .infinity) {
            best = (piece.id, d)
          }
        }
      }
      parent.selectedTrail = best?.0
    }

    private static func distance(_ p: MKMapPoint, _ a: MKMapPoint, _ b: MKMapPoint) -> Double {
      let dx = b.x - a.x, dy = b.y - a.y
      let lengthSquared = dx * dx + dy * dy
      let t = lengthSquared > 0 ? max(0, min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lengthSquared)) : 0
      return hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: any MKOverlay) -> MKOverlayRenderer {
      if let tiles = overlay as? MKTileOverlay {
        return MKTileOverlayRenderer(tileOverlay: tiles)
      }
      if let line = overlay as? TrailLine {
        let renderer = MKPolylineRenderer(polyline: line)
        if line.isTrack {
          renderer.strokeColor = UIColor(Palette.water)
          renderer.lineWidth = 5
        } else if line.isHighlight {
          renderer.strokeColor = UIColor(Palette.forest)
          renderer.lineWidth = 6
        } else {
          renderer.strokeColor = UIColor(Palette.rust).withAlphaComponent(0.85)
          renderer.lineWidth = 2.5
          renderer.lineDashPattern = [6, 4]
        }
        renderer.lineCap = .round
        return renderer
      }
      return MKOverlayRenderer(overlay: overlay)
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: any MKAnnotation) -> MKAnnotationView? {
      guard annotation is PlacePin else {
        return nil
      }
      let view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "place")
      view.markerTintColor = UIColor(Palette.forest)
      view.glyphImage = UIImage(systemName: "binoculars.fill")
      view.canShowCallout = true
      view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
      return view
    }

    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
      if let pin = view.annotation as? PlacePin {
        parent.onPlace(pin.placeID)
      }
    }
  }
}

struct MapScreen: View {
  @Environment(AppModel.self) private var app
  @State private var selected: String?
  @State private var query = ""

  var body: some View {
    if let park = app.currentPark ?? app.yourParks.first {
      content(park)
    } else {
      ContentUnavailableView {
        Label("Pick a park first", systemImage: "map")
      } description: {
        Text("Open a park from the Parks tab and its map shows up here.")
      }
      .background(Palette.paper)
    }
  }

  private func content(_ park: ParkSummary) -> some View {
    let pack = app.store.packs[park.code]
    let trail = selected.flatMap { id in pack?.trails.first { $0.id == id } }
    return ZStack(alignment: .top) {
      ParkMapView(
        park: park,
        pack: pack,
        viewpoints: app.catalog.guide(park.code)?.viewpoints ?? [],
        selectedTrail: $selected,
        focusTrail: app.mapFocus,
        track: app.recorder.track
      ) { placeID in
        app.mapPath.append(.viewpoint(park: park.code, place: placeID))
      }
      .id(park.code + (pack == nil ? "-online" : "-saved"))
      .ignoresSafeArea()

      VStack(spacing: 10) {
        header(park, pack: pack)
        if !query.isEmpty, let pack {
          results(pack)
        }
        Spacer()
        if app.recorder.isActive {
          Button {
            app.mapPath = [.hike]
          } label: {
            Label("Recording · \(Units.miles(app.recorder.distance))", systemImage: "record.circle")
              .font(Typeface.body(15, .bold))
              .foregroundStyle(Palette.card)
              .frame(maxWidth: .infinity, minHeight: 48)
              .background(Capsule().fill(Palette.rust))
          }
          .buttonStyle(.plain)
        }
        if let trail {
          trailCard(park, trail)
        } else if pack == nil {
          Card {
            VStack(alignment: .leading, spacing: 10) {
              Text("Save \(park.name) to use this map with no signal, with its trails and elevation.").font(Typeface.body(15)).foregroundStyle(Palette.ink)
              Button("Download for offline") { app.mapPath.append(.download(park.code)) }
                .buttonStyle(PrimaryButtonStyle())
            }
          }
        }
      }
      .padding(.horizontal, 16)
      .padding(.top, 8)
      .padding(.bottom, 96)
    }
    .toolbar(.hidden, for: .navigationBar)
    .onAppear {
      if let focus = app.mapFocus {
        selected = focus
      }
    }
    .onChange(of: app.mapFocus) { _, focus in
      if let focus {
        selected = focus
      }
    }
  }

  private func header(_ park: ParkSummary, pack: ParkPack?) -> some View {
    VStack(alignment: .leading, spacing: 8) {
      HStack(spacing: 8) {
        Menu {
          ForEach(app.yourParks) { other in
            Button(other.name) {
              app.currentParkCode = other.code
              selected = nil
              app.mapFocus = nil
            }
          }
        } label: {
          HStack(spacing: 4) {
            Text(park.name.uppercased()).font(Typeface.poster(26)).foregroundStyle(Palette.ink).lineLimit(1)
            Image(systemName: "chevron.down").font(.system(size: 12, weight: .bold)).foregroundStyle(Palette.muted)
          }
        }
        .accessibilityLabel("\(park.name). Change park")
        Spacer()
        if pack != nil, !app.connectivity.isOnline {
          Chip(text: "No signal · map saved", systemImage: "antenna.radiowaves.left.and.right.slash", foreground: Palette.card, background: Palette.forest)
        }
      }
      if pack != nil {
        HStack(spacing: 8) {
          Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
          TextField("Search \(park.name) trails", text: $query).font(Typeface.body(15))
          if !query.isEmpty {
            Button {
              query = ""
            } label: {
              Image(systemName: "xmark.circle.fill").foregroundStyle(Palette.muted)
            }
            .accessibilityLabel("Clear search")
          }
        }
        .padding(.horizontal, 16)
        .frame(height: 46)
        .background(Capsule().fill(Palette.card))
        .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
      }
    }
    .padding(12)
    .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.paper.opacity(0.94)))
  }

  private func results(_ pack: ParkPack) -> some View {
    let matches = pack.trails.filter { $0.name.localizedCaseInsensitiveContains(query) }.prefix(6)
    return VStack(spacing: 0) {
      ForEach(Array(matches)) { trail in
        Button {
          selected = trail.id
          app.mapFocus = trail.id
          query = ""
        } label: {
          HStack {
            Text(trail.name).font(Typeface.body(15, .semibold)).foregroundStyle(Palette.ink)
            Spacer()
            Text(Units.miles(trail.roundTrip)).font(Typeface.body(13)).foregroundStyle(Palette.muted)
          }
          .frame(minHeight: 46)
          .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
      }
    }
    .padding(.horizontal, 14)
    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Palette.card))
  }

  private func trailCard(_ park: ParkSummary, _ trail: Trail) -> some View {
    Card {
      VStack(alignment: .leading, spacing: 10) {
        HStack {
          Text(trail.name.uppercased()).font(Typeface.poster(28)).foregroundStyle(Palette.ink).lineLimit(1).minimumScaleFactor(0.6)
          Spacer()
          Button {
            selected = nil
          } label: {
            Image(systemName: "xmark")
          }
          .buttonStyle(RoundIconButtonStyle())
          .accessibilityLabel("Close")
        }
        HStack(spacing: 14) {
          let distance = app.hikeDistance(trail, in: park.code)
          Label(distance.isLoop ? "\(Units.miles(distance.meters)) loop" : "\(Units.miles(distance.meters)) round trip", systemImage: "arrow.left.and.right")
          if let climb = trail.climb {
            Label("+\(Units.feet(climb))", systemImage: "arrow.up.right")
          }
          Label(Units.hours(trail.estimatedHours), systemImage: "clock")
        }
        .font(Typeface.body(13, .semibold))
        .foregroundStyle(Palette.muted)
        HStack(spacing: 10) {
          Button("Start hike") { app.startHike(park, trail: trail) }
            .buttonStyle(PrimaryButtonStyle(color: Palette.rust))
            .disabled(app.recorder.isActive)
          Button("Details") { app.mapPath.append(.trail(park: park.code, trail: trail.id)) }
            .buttonStyle(SecondaryButtonStyle())
        }
      }
    }
  }
}
