import SwiftUI

struct RangerView: View {
  @Environment(AppModel.self) private var app
  @State private var question = ""
  @FocusState private var isTyping: Bool

  private let suggestions = ["Best sunset spot tonight?", "Easy hikes with kids", "Can I bring my dog?", "Where can I get water?", "What's the weather like?"]

  var body: some View {
    if let park = app.currentPark ?? app.yourParks.first {
      content(park)
    } else {
      ContentUnavailableView("Pick a park first", systemImage: "bubble.left", description: Text("The ranger answers about the park you have open."))
        .background(Palette.paper)
    }
  }

  private func content(_ park: ParkSummary) -> some View {
    let answers = app.ranger.conversation(for: park.code)
    return VStack(spacing: 0) {
      ScrollViewReader { proxy in
        ScrollView {
          VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 6) {
              HStack {
                Eyebrow(text: "Ranger", color: Palette.rust)
                Spacer()
                if !app.connectivity.isOnline {
                  Chip(text: "Offline", systemImage: "wifi.slash")
                }
              }
              Menu {
                ForEach(app.yourParks) { other in
                  Button(other.name) { app.currentParkCode = other.code }
                }
              } label: {
                HStack(spacing: 4) {
                  Text(park.name.uppercased()).font(Typeface.poster(40)).foregroundStyle(Palette.ink).lineLimit(1).minimumScaleFactor(0.6)
                  Image(systemName: "chevron.down").font(.system(size: 13, weight: .bold)).foregroundStyle(Palette.muted)
                }
              }
              .accessibilityLabel("\(park.name). Change park")
              Text("\(park.name) guide · \(app.writer.isAvailable ? "answers on this iPhone" : "answers from the guide")")
                .font(Typeface.body(13))
                .foregroundStyle(Palette.muted)
            }
            if answers.isEmpty {
              Text("Ask about trails, sunset, pets, water, weather or anything in the park's guide. It all works with no signal.")
                .font(Typeface.body(15))
                .foregroundStyle(Palette.muted)
            }
            ForEach(answers) { answer in
              exchange(answer, park: park).id(answer.id)
            }
          }
          .padding(20)
        }
        .onChange(of: answers.last?.text) { _, _ in
          if let last = answers.last {
            withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
          }
        }
      }
      VStack(spacing: 10) {
        ScrollView(.horizontal) {
          HStack(spacing: 8) {
            ForEach(suggestions, id: \.self) { suggestion in
              Button(suggestion) { send(suggestion, park) }
                .font(Typeface.body(14, .semibold))
                .foregroundStyle(Palette.forest)
                .padding(.horizontal, 14)
                .frame(height: 40)
                .background(Capsule().fill(Palette.card))
                .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
                .buttonStyle(.plain)
            }
          }
          .padding(.horizontal, 20)
        }
        .scrollIndicators(.hidden)
        HStack(spacing: 8) {
          TextField("Ask the ranger", text: $question, axis: .vertical)
            .font(Typeface.body(16))
            .focused($isTyping)
            .submitLabel(.send)
            .onSubmit { send(question, park) }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Palette.card))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Palette.line, lineWidth: 1))
          Button {
            send(question, park)
          } label: {
            Image(systemName: "arrow.up").font(.system(size: 17, weight: .bold)).foregroundStyle(Palette.card)
              .frame(width: 48, height: 48)
              .background(Circle().fill(Palette.forest))
          }
          .buttonStyle(.plain)
          .disabled(question.trimmingCharacters(in: .whitespaces).isEmpty)
          .accessibilityLabel("Ask")
        }
        .padding(.horizontal, 20)
      }
      .padding(.bottom, 96)
      .padding(.top, 6)
    }
    .background(Palette.paper)
    .toolbar(.hidden, for: .navigationBar)
    .onAppear {
      if let draft = app.rangerDraft {
        app.rangerDraft = nil
        if !draft.isEmpty {
          send(draft, park)
        }
      }
    }
  }

  private func exchange(_ answer: Ranger.Answer, park: ParkSummary) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      Text(answer.question)
        .font(Typeface.body(15, .semibold))
        .foregroundStyle(Palette.card)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Palette.forest))
        .frame(maxWidth: .infinity, alignment: .trailing)
      if answer.isThinking {
        ProgressView().tint(Palette.forest)
      } else {
        Text(answer.text).font(Typeface.body(16)).foregroundStyle(Palette.ink).textSelection(.enabled)
        if let id = answer.trailID, let trail = app.store.trail(id, in: park.code) {
          Button {
            app.tab = .parks
            app.parksPath.append(.trail(park: park.code, trail: id))
          } label: {
            HStack {
              VStack(alignment: .leading, spacing: 2) {
                Text(trail.name.uppercased()).font(Typeface.poster(20)).foregroundStyle(Palette.ink)
                Text("\(Units.miles(trail.roundTrip)) · \(trail.climb.map(Units.feet) ?? "") · saved offline").font(Typeface.body(12)).foregroundStyle(Palette.muted)
              }
              Spacer()
              Image(systemName: "chevron.right").foregroundStyle(Palette.muted)
            }
            .padding(12)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Palette.card))
          }
          .buttonStyle(.plain)
        }
        if let source = answer.source {
          Label("From \(source.lowercased().hasPrefix("today") ? "today's sun times" : "the guide: \(source)")", systemImage: answer.isWritten ? "iphone" : "book")
            .font(Typeface.body(12, .semibold))
            .foregroundStyle(Palette.muted)
        }
      }
    }
  }

  private func send(_ text: String, _ park: ParkSummary) {
    let asked = text.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !asked.isEmpty else {
      return
    }
    question = ""
    isTyping = false
    Task {
      await app.ranger.ask(asked, park: park, guide: app.catalog.guide(park.code), pack: app.store.packs[park.code], alerts: app.store.alerts[park.code])
    }
  }
}
