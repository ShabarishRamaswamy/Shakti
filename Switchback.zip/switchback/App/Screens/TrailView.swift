import Charts
import MapKit
import SkyKit
import SwiftUI

struct TrailView: View {
  @Environment(AppModel.self) private var app
  let parkCode: String
  let trailID: String

  var body: some View {
    if let park = app.catalog.park(parkCode), let trail = app.store.trail(trailID, in: parkCode) {
      content(park, trail)
    } else {
      ContentUnavailableView("Trail not saved", systemImage: "point.topleft.down.to.point.bottomright.curvepath")
    }
  }

  private func content(_ park: ParkSummary, _ trail: Trail) -> some View {
    let hike = app.guideHike(for: trail, in: parkCode)
    let distance = app.hikeDistance(trail, in: parkCode)
    return ScrollView {
      VStack(alignment: .leading, spacing: 20) {
        HStack(spacing: 8) {
          Button {
            app.showOnMap(park, trail: trail.id)
          } label: {
            Label("Map", systemImage: "map")
          }
          .font(Typeface.body(14, .bold))
          Spacer()
          Chip(text: "Saved offline", systemImage: "checkmark", foreground: Palette.card, background: Palette.forest)
        }
        VStack(alignment: .leading, spacing: 6) {
          Eyebrow(text: "Trail · \(park.name)", color: Palette.rust)
          Text(trail.name.uppercased()).font(Typeface.poster(48)).foregroundStyle(Palette.ink).lineLimit(3).minimumScaleFactor(0.6)
          if let surface = trail.surface {
            Text("\(surface) surface\(trail.isSeasonal ? " · seasonal" : "")").font(Typeface.body(14)).foregroundStyle(Palette.muted)
          }
        }
        Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 12) {
          GridRow {
            stat(distance.isLoop ? "Loop" : "Round trip", Units.miles(distance.meters))
            stat("Climb", trail.climb.map(Units.feet) ?? "—")
          }
          GridRow {
            stat("Most people take", Units.hours(trail.estimatedHours))
            stat("Highest point", trail.highest.map(Units.feet) ?? "—")
          }
        }
        elevation(trail)
        sunset(park, trail)
        if let hike {
          VStack(alignment: .leading, spacing: 8) {
            Eyebrow(text: "What to expect")
            Text(hike.body.isEmpty ? hike.summary : hike.body).font(Typeface.body(16)).foregroundStyle(Palette.ink).lineLimit(14)
          }
        }
        goodToKnow(park, trail, hike: hike)
        Button {
          app.startHike(park, trail: trail)
        } label: {
          Label("Start hike", systemImage: "figure.hiking")
        }
        .buttonStyle(PrimaryButtonStyle(color: Palette.rust))
        Button {
          app.ask("Tell me about \(trail.name).", about: park)
        } label: {
          Label("Ask about this trail", systemImage: "bubble.left")
        }
        .buttonStyle(SecondaryButtonStyle())
      }
      .padding(20)
      .padding(.bottom, 100)
    }
    .background(Palette.paper)
    .navigationBarTitleDisplayMode(.inline)
    .task {
      if trail.profile == nil, app.connectivity.isOnline {
        await app.store.ensureProfile(trail.id, in: parkCode)
      }
    }
  }

  private func stat(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.label(24, .heavy)).foregroundStyle(Palette.ink)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding(14)
    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Palette.card))
    .accessibilityElement(children: .combine)
  }

  @ViewBuilder
  private func elevation(_ trail: Trail) -> some View {
    VStack(alignment: .leading, spacing: 8) {
      Eyebrow(text: "Elevation")
      if let profile = trail.profile {
        Chart(profile, id: \.distance) { point in
          AreaMark(x: .value("Miles", point.distance / 1609.34), y: .value("Feet", point.elevation * 3.28084))
            .foregroundStyle(Palette.forest.opacity(0.18))
          LineMark(x: .value("Miles", point.distance / 1609.34), y: .value("Feet", point.elevation * 3.28084))
            .foregroundStyle(Palette.forest)
        }
        .chartYScale(domain: .automatic(includesZero: false))
        .chartXAxisLabel("miles one way")
        .frame(height: 150)
        .accessibilityLabel("Elevation from \(Units.feet(profile.first?.elevation ?? 0)) to a high point of \(Units.feet(trail.highest ?? 0))")
      } else {
        Text(app.connectivity.isOnline ? "Loading elevation…" : "Elevation for this trail loads the next time you're online.")
          .font(Typeface.body(14))
          .foregroundStyle(Palette.muted)
      }
    }
  }

  @ViewBuilder
  private func sunset(_ park: ParkSummary, _ trail: Trail) -> some View {
    let spot = trail.far ?? trail.trailhead ?? Coord(park.lat ?? 0, park.lon ?? 0)
    let light = app.daylight(at: spot, zone: park.zone)
    let oneWay = trail.estimatedHours.upperBound / (trail.isLoop ? 1 : 2)
    let leaveBy = light.eveningGoldenStart?.addingTimeInterval(-oneWay * 3600)
    Card {
      VStack(alignment: .leading, spacing: 12) {
        Eyebrow(text: trail.isLoop ? "Golden hour on the trail · tonight" : "Sunset from the far end · tonight")
        HStack {
          lightStat("Golden light", clockText(light.eveningGoldenStart, park.zone))
          lightStat("Sunset", clockText(light.sunset, park.zone))
          lightStat("Last light", clockText(light.lastLight, park.zone))
        }
        if let leaveBy, leaveBy > Date() {
          Text("Leave the trailhead by \(clockText(leaveBy, park.zone)) to be there for golden hour. Bring a headlamp for the walk back.")
            .font(Typeface.body(14))
            .foregroundStyle(Palette.ink)
        }
      }
    }
  }

  private func lightStat(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.label(18, .heavy)).foregroundStyle(Palette.ink)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
  }

  private func notes(_ trail: Trail, hike: GuideItem?) -> [String] {
    let shortName = trail.name.replacingOccurrences(of: " Trail", with: "")
    var notes = (app.store.alerts[parkCode]?.alerts ?? [])
      .filter { $0.title.localizedCaseInsensitiveContains(shortName) }
      .map { "\($0.category): \($0.title)" }
    if trail.isSeasonal {
      notes.append("This trail is seasonal. Check it's open before you go.")
    }
    if let pets = hike?.pets, !pets.isEmpty {
      notes.append(pets)
    }
    if let access = hike?.accessibility, !access.isEmpty {
      notes.append(access)
    }
    return notes
  }

  @ViewBuilder
  private func goodToKnow(_ park: ParkSummary, _ trail: Trail, hike: GuideItem?) -> some View {
    let notes = notes(trail, hike: hike)
    if !notes.isEmpty {
      VStack(alignment: .leading, spacing: 8) {
        Eyebrow(text: "Good to know")
        ForEach(notes, id: \.self) { note in
          Label(note, systemImage: "exclamationmark.circle").font(Typeface.body(14)).foregroundStyle(Palette.ink)
        }
        Text("From the \(park.name) guide · saved offline").font(Typeface.body(12)).foregroundStyle(Palette.muted)
      }
    }
  }
}

// MARK: Viewpoint

struct ViewpointView: View {
  @Environment(AppModel.self) private var app
  let parkCode: String
  let placeID: String
  @State private var reminded = false
  @State private var advice: String?

  var body: some View {
    if let park = app.catalog.park(parkCode), let place = app.catalog.guide(parkCode)?.places.first(where: { ($0.id ?? $0.title) == placeID }), let spot = place.coordinate {
      content(park, place, Coord(spot))
    } else {
      ContentUnavailableView("Viewpoint not found", systemImage: "binoculars")
    }
  }

  private func content(_ park: ParkSummary, _ place: Place, _ spot: Coord) -> some View {
    let light = app.daylight(at: spot, zone: park.zone)
    let setDirection = light.sunset.map { DaylightCalculator.sun(at: $0, latitude: spot.lat, longitude: spot.lon).azimuth }
    let moonDirection = light.moonrise.map { DaylightCalculator.moon(at: $0, latitude: spot.lat, longitude: spot.lon).azimuth }
    let reminderTime = light.eveningGoldenStart?.addingTimeInterval(-20 * 60)
    return ScrollView {
      VStack(alignment: .leading, spacing: 0) {
        ParkPhoto(park: park, image: place.image).frame(height: 240)
        VStack(alignment: .leading, spacing: 18) {
          Eyebrow(text: "Viewpoint · \(park.name)", color: Palette.rust)
          Text(place.title.uppercased()).font(Typeface.poster(46)).foregroundStyle(Palette.ink).lineLimit(3).minimumScaleFactor(0.6)
          if let setDirection {
            Text("The sun sets in the \(Directions.compassWord(setDirection)) from here.").font(Typeface.body(16)).foregroundStyle(Palette.ink)
          }
          Card {
            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 12) {
              GridRow {
                cell("Golden hour", "\(clockText(light.eveningGoldenStart, park.zone)) – \(clockText(light.eveningGoldenEnd, park.zone))")
                cell("Sunset", clockText(light.sunset, park.zone))
              }
              GridRow {
                cell(light.isMoonFull ? "Full moon rises" : "Moonrise", light.moonrise.map { "\(clockText($0, park.zone))\(moonDirection.map { " · \(Directions.compassPoint($0))" } ?? "")" } ?? "—")
                cell("Last light", clockText(light.lastLight, park.zone))
              }
            }
          }
          if let advice {
            Text(advice).font(Typeface.body(15)).foregroundStyle(Palette.ink)
            Label(app.writer.isAvailable ? "Written on this iPhone · times shift a little with the terrain" : "Times shift a little with the terrain", systemImage: "iphone")
              .font(Typeface.body(12, .semibold))
              .foregroundStyle(Palette.muted)
          }
          if !place.summary.isEmpty {
            Text(place.body.isEmpty ? place.summary : place.body).font(Typeface.body(15)).foregroundStyle(Palette.muted).lineLimit(10)
          }
          HStack(spacing: 12) {
            if let reminderTime, reminderTime > Date() {
              Button(reminded ? "Reminder set" : "Remind me at \(clockText(reminderTime, park.zone))") {
                Task {
                  reminded = await Reminders.remind(at: reminderTime, title: "Golden hour at \(place.title)", body: "Golden light starts in 20 minutes.")
                }
              }
              .buttonStyle(PrimaryButtonStyle())
              .disabled(reminded)
            }
            Button("Directions") {
              let item = MKMapItem(location: CLLocation(latitude: spot.lat, longitude: spot.lon), address: nil)
              item.name = place.title
              item.openInMaps()
            }
            .buttonStyle(SecondaryButtonStyle())
          }
        }
        .padding(20)
        .padding(.bottom, 100)
      }
    }
    .background(Palette.paper)
    .ignoresSafeArea(edges: .top)
    .toolbarBackground(.hidden, for: .navigationBar)
    .task {
      advice = await viewpointAdvice(park, place, light)
    }
  }

  private func cell(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.label(19, .heavy)).foregroundStyle(Palette.ink)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .accessibilityElement(children: .combine)
  }

  private func viewpointAdvice(_ park: ParkSummary, _ place: Place, _ light: Daylight) async -> String {
    let zone = park.zone
    let arrive = light.eveningGoldenStart.map { clockText($0.addingTimeInterval(-15 * 60), zone) } ?? "late afternoon"
    let fallback = "Arrive by \(arrive) to settle in before the light turns gold."
    let facts = "Viewpoint: \(place.title). Golden hour \(clockText(light.eveningGoldenStart, zone)) to \(clockText(light.eveningGoldenEnd, zone)). Sunset \(clockText(light.sunset, zone)). Moonrise \(clockText(light.moonrise, zone)), moon \(Int((light.moonIllumination * 100).rounded()))% lit. Last light \(clockText(light.lastLight, zone)). About: \(place.summary.prefix(300))"
    let instructions = "You are a park ranger who loves photography. In one or two sentences, say when to arrive and what to watch for, using only these facts and times. No emoji."
    return await app.writer.write(instructions: instructions, prompt: facts, maxTokens: 90) ?? fallback
  }
}
