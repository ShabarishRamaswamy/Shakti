import SwiftUI

struct ParkView: View {
  @Environment(AppModel.self) private var app
  let code: String
  @State private var pick: String?

  var body: some View {
    if let park = app.catalog.park(code) {
      content(park)
    } else {
      ContentUnavailableView("Park not found", systemImage: "mountain.2")
    }
  }

  private func content(_ park: ParkSummary) -> some View {
    let guide = app.catalog.guide(code)
    let pack = app.store.packs[code]
    return ScrollView {
      VStack(alignment: .leading, spacing: 0) {
        ParkPhoto(park: park).frame(height: 260)
        VStack(alignment: .leading, spacing: 20) {
          header(park)
          today(park)
          pickCard(park)
          trails(park, guide: guide, pack: pack)
          viewpoints(park, guide: guide)
          alerts(park)
          Button {
            app.ask("", about: park)
          } label: {
            Label("Ask the ranger", systemImage: "bubble.left")
          }
          .buttonStyle(PrimaryButtonStyle())
          if app.store.isReady(code) {
            Button("Remove offline copy", role: .destructive) { app.store.remove(code) }
              .font(Typeface.body(14, .semibold))
              .frame(maxWidth: .infinity, minHeight: 44)
          }
        }
        .padding(20)
        .padding(.bottom, 100)
      }
    }
    .background(Palette.paper)
    .ignoresSafeArea(edges: .top)
    .toolbarBackground(.hidden, for: .navigationBar)
    .onAppear { app.currentParkCode = code }
    .task {
      pick = await app.rangersPick(for: park)
      if app.connectivity.isOnline {
        await app.store.refreshAlerts(code)
      }
    }
  }

  private func header(_ park: ParkSummary) -> some View {
    VStack(alignment: .leading, spacing: 8) {
      Text(park.name.uppercased()).font(Typeface.poster(52)).foregroundStyle(Palette.ink).lineLimit(2).minimumScaleFactor(0.6)
      Text(park.stateNames.uppercased()).font(Typeface.body(13, .bold)).tracking(1.2).foregroundStyle(Palette.muted)
      if app.store.isReady(code) {
        Chip(text: "Ready offline", systemImage: "checkmark", foreground: Palette.card, background: Palette.forest)
      } else {
        NavigationLink(value: Route.download(code)) {
          Label(app.store.isDownloading(code) ? "Saving for offline…" : "Download for offline", systemImage: "arrow.down.to.line")
        }
        .buttonStyle(SecondaryButtonStyle())
      }
    }
  }

  private func today(_ park: ParkSummary) -> some View {
    let light = app.daylight(for: park)
    let zone = park.zone
    return Card {
      VStack(alignment: .leading, spacing: 12) {
        HStack {
          Eyebrow(text: "Today · \(Date().formatted(Date.FormatStyle(date: .abbreviated, time: .omitted, timeZone: zone)))")
          Spacer()
          Text("Now \(clockText(app.recorder.location?.timestamp ?? Date(), zone))").font(Typeface.body(13, .semibold)).foregroundStyle(Palette.muted)
        }
        Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 12) {
          GridRow {
            stat("Sunrise", clockText(light?.sunrise, zone))
            stat("Sunset", clockText(light?.sunset, zone))
          }
          GridRow {
            stat("Golden hour", "\(clockText(light?.eveningGoldenStart, zone)) – \(clockText(light?.eveningGoldenEnd, zone))")
            stat("Moon · \(Int(((light?.moonIllumination ?? 0) * 100).rounded()))%", light?.moonrise.map { "Rises \(clockText($0, zone))" } ?? "Up all evening")
          }
        }
      }
    }
  }

  private func stat(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.label(20, .heavy)).foregroundStyle(Palette.ink)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .accessibilityElement(children: .combine)
  }

  private func pickCard(_ park: ParkSummary) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      Eyebrow(text: "Ranger's pick", color: Palette.gold)
      Text(pick ?? "Thinking about today…").font(Typeface.body(16)).foregroundStyle(Palette.card).fixedSize(horizontal: false, vertical: true)
      if app.writer.isAvailable {
        Label("Written on this iPhone", systemImage: "iphone").font(Typeface.body(12, .semibold)).foregroundStyle(Palette.gold.opacity(0.9))
      }
    }
    .padding(18)
    .frame(maxWidth: .infinity, alignment: .leading)
    .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.forest))
  }

  @ViewBuilder
  private func trails(_ park: ParkSummary, guide: ParkGuide?, pack: ParkPack?) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      HStack {
        Eyebrow(text: "Trails")
        Spacer()
        if pack != nil {
          Button("On the map") { app.showOnMap(park) }.font(Typeface.body(14, .bold))
        }
      }
      if let pack {
        let listed = pack.trails.sorted { ($0.profile == nil ? 1 : 0, $0.roundTrip) < ($1.profile == nil ? 1 : 0, $1.roundTrip) }.prefix(14)
        VStack(spacing: 0) {
          ForEach(Array(listed)) { trail in
            NavigationLink(value: Route.trail(park: code, trail: trail.id)) {
              TrailRow(trail: trail, distance: app.hikeDistance(trail, in: code))
            }
            .buttonStyle(.plain)
          }
        }
        .padding(.horizontal, 14)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
        Text("\(pack.trails.count) mapped trails saved. Search them on the map.").font(Typeface.body(13)).foregroundStyle(Palette.muted)
      } else if let hikes = guide?.hikes, !hikes.isEmpty {
        VStack(spacing: 0) {
          ForEach(hikes.prefix(8), id: \.stableID) { hike in
            VStack(alignment: .leading, spacing: 3) {
              Text(hike.title).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink)
              Text([hike.duration, hike.summary].filter { !$0.isEmpty }.joined(separator: " · ")).font(Typeface.body(13)).foregroundStyle(Palette.muted).lineLimit(2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 10)
            .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
          }
        }
        .padding(.horizontal, 14)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
        Text("Download the park for trail maps and elevation.").font(Typeface.body(13)).foregroundStyle(Palette.muted)
      } else {
        Text("Download the park for its trail map.").font(Typeface.body(14)).foregroundStyle(Palette.muted)
      }
    }
  }

  @ViewBuilder
  private func viewpoints(_ park: ParkSummary, guide: ParkGuide?) -> some View {
    let views = guide?.viewpoints ?? []
    if !views.isEmpty {
      VStack(alignment: .leading, spacing: 10) {
        Eyebrow(text: "Viewpoints")
        ScrollView(.horizontal) {
          HStack(spacing: 12) {
            ForEach(views.prefix(12), id: \.title) { place in
              NavigationLink(value: Route.viewpoint(park: code, place: place.id ?? place.title)) {
                VStack(alignment: .leading, spacing: 0) {
                  ParkPhoto(park: park, image: place.image).frame(width: 170, height: 104)
                  Text(place.title).font(Typeface.body(14, .bold)).foregroundStyle(Palette.ink).lineLimit(2)
                    .frame(width: 150, alignment: .leading)
                    .padding(10)
                }
                .background(Palette.card)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
              }
              .buttonStyle(.plain)
            }
          }
        }
        .scrollIndicators(.hidden)
      }
    }
  }

  @ViewBuilder
  private func alerts(_ park: ParkSummary) -> some View {
    let set = app.store.alerts[code]
    VStack(alignment: .leading, spacing: 8) {
      if let set, !set.alerts.isEmpty {
        Eyebrow(text: "Alerts", color: Palette.rust)
        ForEach(set.alerts.prefix(4)) { alert in
          VStack(alignment: .leading, spacing: 2) {
            Text(alert.title).font(Typeface.body(15, .semibold)).foregroundStyle(Palette.ink)
            Text(alert.category).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.rust)
          }
        }
      }
      Text("Closures and alerts from the park update when you're online.\(set.map { " Last checked \(clockText($0.fetchedAt, .current))." } ?? "")")
        .font(Typeface.body(13))
        .foregroundStyle(Palette.muted)
    }
  }
}

struct TrailRow: View {
  let trail: Trail
  let distance: (meters: Double, isLoop: Bool, fromGuide: Bool)

  var body: some View {
    HStack(spacing: 12) {
      Text(String(format: "%.1f", distance.meters / 1609.34))
        .font(Typeface.label(16, .heavy))
        .foregroundStyle(Palette.card)
        .frame(width: 46, height: 46)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Palette.rust))
        .accessibilityHidden(true)
      VStack(alignment: .leading, spacing: 2) {
        Text(trail.name).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink).lineLimit(1)
        Text(detail).font(Typeface.body(13)).foregroundStyle(Palette.muted).lineLimit(1)
      }
      Spacer(minLength: 0)
      Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundStyle(Palette.muted)
    }
    .frame(minHeight: 64)
    .contentShape(Rectangle())
    .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
  }

  private var detail: String {
    var parts = [distance.isLoop ? "\(Units.miles(distance.meters)) loop" : "\(Units.miles(distance.meters)) round trip"]
    if let climb = trail.climb {
      parts.append(Units.feet(climb))
    }
    parts.append(Units.hours(trail.estimatedHours))
    return parts.joined(separator: " · ")
  }
}

// MARK: Download

struct DownloadView: View {
  @Environment(AppModel.self) private var app
  @Environment(\.dismiss) private var dismiss
  let code: String

  var body: some View {
    let park = app.catalog.park(code)
    let progress = app.store.progress[code]
    let ready = app.store.isReady(code)
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        Text("DOWNLOAD").font(Typeface.body(12, .bold)).tracking(1.4).foregroundStyle(Palette.rust)
        Text((park?.name ?? code).uppercased()).font(Typeface.poster(56)).foregroundStyle(Palette.ink)
        Text(park?.stateNames.uppercased() ?? "").font(Typeface.body(13, .bold)).tracking(1.2).foregroundStyle(Palette.muted)
        Card {
          VStack(alignment: .leading, spacing: 10) {
            Text(ready ? "Saved for offline" : "Saving for offline").font(Typeface.body(15, .semibold)).foregroundStyle(Palette.muted)
            Text("\(Int(((ready ? 1 : progress?.fraction) ?? 0) * 100))%").font(Typeface.poster(64)).foregroundStyle(Palette.forest)
            ProgressView(value: ready ? 1 : progress?.fraction ?? 0).tint(Palette.rust)
            Text("Keep Switchback open while it saves; if you leave, it picks up where it stopped. Wi-Fi recommended.")
              .font(Typeface.body(13))
              .foregroundStyle(Palette.muted)
          }
        }
        Eyebrow(text: "What you get offline")
        VStack(spacing: 0) {
          ForEach(ParkStore.Step.allCases, id: \.self) { step in
            let state = ready ? .done : progress?.steps[step] ?? .waiting
            HStack {
              Text(step.title).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink)
              Spacer()
              Text(state.label)
                .font(Typeface.body(13, .bold))
                .foregroundStyle(state == .done ? Palette.forest : Palette.muted)
            }
            .frame(minHeight: 52)
            .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
            .accessibilityElement(children: .combine)
          }
        }
        .padding(.horizontal, 14)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
        Text(app.writer.isAvailable ? "The ranger answers with Apple Intelligence on this iPhone." : "Without Apple Intelligence, the ranger answers straight from the guide.")
          .font(Typeface.body(13))
          .foregroundStyle(Palette.muted)
        if ready {
          Button("Open the park") {
            if let park {
              dismiss()
              app.parksPath = [.park(park.code)]
            }
          }
          .buttonStyle(PrimaryButtonStyle())
        } else if progress != nil {
          Button("Stop") { app.store.cancel(code) }
            .buttonStyle(SecondaryButtonStyle())
        } else {
          Button("Download") { start() }
            .buttonStyle(PrimaryButtonStyle())
            .disabled(!app.connectivity.isOnline)
          if !app.connectivity.isOnline {
            Text("Connect to the internet to download.").font(Typeface.body(13)).foregroundStyle(Palette.rust)
          }
        }
      }
      .padding(20)
      .padding(.bottom, 100)
    }
    .background(Palette.paper)
    .onAppear {
      if !ready, progress == nil, app.connectivity.isOnline {
        start()
      }
    }
  }

  private func start() {
    guard let park = app.catalog.park(code) else {
      return
    }
    app.currentParkCode = code
    app.store.download(park, guide: app.catalog.guide(code))
  }
}
