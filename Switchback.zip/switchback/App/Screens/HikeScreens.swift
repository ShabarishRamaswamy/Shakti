import MessageUI
import PhotosUI
import SkyKit
import SwiftData
import SwiftUI

// MARK: Recording

struct HikeView: View {
  @Environment(AppModel.self) private var app
  @State private var finishedID: PersistentIdentifier?

  var body: some View {
    let recorder = app.recorder
    TimelineView(.periodic(from: .now, by: 1)) { context in
      ScrollView {
        VStack(alignment: .leading, spacing: 18) {
          Eyebrow(text: recorder.state == .paused ? "Paused · \(recorder.trail?.name ?? "")" : "Recording · \(recorder.trail?.name ?? "free walk")", color: Palette.rust)
          Text((recorder.trail?.name ?? recorder.park?.name ?? "Hike").uppercased())
            .font(Typeface.poster(44)).foregroundStyle(Palette.ink).lineLimit(2).minimumScaleFactor(0.6)
          Grid(horizontalSpacing: 12, verticalSpacing: 12) {
            GridRow {
              big("Distance", Units.miles(recorder.distance, digits: 2))
              big("Time", Units.clock(recorder.movingSeconds))
            }
            GridRow {
              big("Climbed", "+\(Units.feet(recorder.climb))")
              big("To the top", remainingClimb.map(Units.feet) ?? "—")
            }
          }
          lightNote(context.date)
          HStack(spacing: 12) {
            Button(recorder.state == .paused ? "Resume" : "Pause") {
              recorder.state == .paused ? recorder.resume() : recorder.pause()
            }
            .buttonStyle(SecondaryButtonStyle())
            Button("Finish") { finish() }
              .buttonStyle(PrimaryButtonStyle(color: Palette.rust))
          }
          NavigationLink(value: Route.safety) {
            Label("Safety: turn-around time and where you are", systemImage: "cross.case")
              .font(Typeface.body(15, .semibold))
              .frame(maxWidth: .infinity, minHeight: 48)
          }
          Text("Keeps recording with the screen locked. Your track stays on this iPhone.")
            .font(Typeface.body(13))
            .foregroundStyle(Palette.muted)
        }
        .padding(20)
        .padding(.bottom, 100)
      }
    }
    .background(Palette.paper)
    .navigationBarBackButtonHidden(recorder.isActive)
    .navigationDestination(item: $finishedID) { id in
      PostcardView(recordID: id)
    }
  }

  private var remainingClimb: Double? {
    guard let top = app.recorder.trail?.highest, let altitude = app.recorder.location?.altitude, app.recorder.location?.verticalAccuracy ?? -1 >= 0 else {
      return nil
    }
    return max(0, top - altitude)
  }

  private func big(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(13, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.poster(38)).foregroundStyle(Palette.ink).monospacedDigit()
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding(16)
    .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Palette.card))
    .accessibilityElement(children: .combine)
  }

  @ViewBuilder
  private func lightNote(_ now: Date) -> some View {
    if let park = app.recorder.park {
      let here = app.recorder.location.map { Coord($0.coordinate) } ?? Coord(park.lat ?? 0, park.lon ?? 0)
      let light = app.daylight(at: here, zone: park.zone)
      if let sunset = light.sunset, let golden = light.eveningGoldenStart, now >= golden, now < sunset {
        note("Golden hour now.", "Sunset in \(Int(sunset.timeIntervalSince(now) / 60)) minutes, at \(clockText(sunset, park.zone)).")
      } else if let last = light.lastLight, let sunset = light.sunset, now >= sunset, now < last {
        note("The sun has set.", "Last light at \(clockText(last, park.zone)). Time to head down.")
      } else if let golden = light.eveningGoldenStart, now < golden, golden.timeIntervalSince(now) < 3 * 3600 {
        note("Golden hour at \(clockText(golden, park.zone)).", "Sunset at \(clockText(light.sunset, park.zone)).")
      }
    }
  }

  private func note(_ title: String, _ detail: String) -> some View {
    VStack(alignment: .leading, spacing: 3) {
      Text(title).font(Typeface.body(16, .bold)).foregroundStyle(Palette.ink)
      Text(detail).font(Typeface.body(14)).foregroundStyle(Palette.ink)
    }
    .padding(14)
    .frame(maxWidth: .infinity, alignment: .leading)
    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Palette.gold))
  }

  private func finish() {
    guard let record = app.finishHike() else {
      return
    }
    finishedID = record.persistentModelID
  }
}

// MARK: Safety

struct SafetyView: View {
  @Environment(AppModel.self) private var app
  @State private var showMessage = false

  /// Walking pace assumed when there's no recorded pace yet: 2 mph.
  private static let defaultPace = 0.894

  var body: some View {
    let recorder = app.recorder
    let park = recorder.park ?? app.currentPark
    let here = recorder.location
    let zone = park?.zone ?? .current
    let coord = here.map { Coord($0.coordinate) } ?? Coord(park?.lat ?? 0, park?.lon ?? 0)
    let light = app.daylight(at: coord, zone: zone)
    let back = backDistance
    let pace = recorder.movingSeconds > 300 && recorder.distance > 200 ? recorder.distance / recorder.movingSeconds : Self.defaultPace
    let walkBack = back / pace
    let turnAround = light.lastLight?.addingTimeInterval(-walkBack)
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        Eyebrow(text: "Safety", color: Palette.rust)
        Text("STAY SAFE").font(Typeface.poster(48)).foregroundStyle(Palette.ink)
        if let turnAround, let last = light.lastLight {
          VStack(alignment: .leading, spacing: 6) {
            Eyebrow(text: "Turn around by", color: Palette.gold)
            Text(clockText(turnAround, zone)).font(Typeface.poster(56)).foregroundStyle(Palette.card)
            Text("to reach the trailhead before last light at \(clockText(last, zone)). It's about \(Units.duration(walkBack)) back from here at your pace.")
              .font(Typeface.body(15))
              .foregroundStyle(Palette.card)
          }
          .padding(18)
          .frame(maxWidth: .infinity, alignment: .leading)
          .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.forest))
        }
        Card {
          VStack(alignment: .leading, spacing: 6) {
            Text("Back to the trailhead").font(Typeface.body(16, .bold)).foregroundStyle(Palette.ink)
            Text("\(Units.miles(back)) · follow your track on the map").font(Typeface.body(14)).foregroundStyle(Palette.muted)
          }
        }
        Card {
          VStack(alignment: .leading, spacing: 8) {
            HStack {
              Eyebrow(text: "Where you are")
              Spacer()
              if !app.connectivity.isOnline {
                Chip(text: "No signal", systemImage: "antenna.radiowaves.left.and.right.slash")
              }
            }
            Text(coordinateText(coord)).font(Typeface.label(22, .heavy)).foregroundStyle(Palette.ink).textSelection(.enabled)
            if let altitude = here?.altitude, (here?.verticalAccuracy ?? -1) >= 0 {
              Text("\(Units.feet(altitude)) elevation").font(Typeface.body(14)).foregroundStyle(Palette.muted)
            }
            Button("Copy") { UIPasteboard.general.string = coordinateText(coord) }
              .font(Typeface.body(14, .bold))
          }
        }
        Button {
          showMessage = true
        } label: {
          Label("Tell someone your plan", systemImage: "message")
        }
        .buttonStyle(SecondaryButtonStyle())
        .disabled(!MFMessageComposeViewController.canSendText())
        Text("Sends your route, where you are and when you'll be back. Messages sends it once you have signal.")
          .font(Typeface.body(13))
          .foregroundStyle(Palette.muted)
        Link(destination: URL(string: "tel://911")!) {
          Label("Call 911", systemImage: "phone.fill")
        }
        .buttonStyle(PrimaryButtonStyle(color: Palette.rust))
        Text("With no signal, iPhone 14 and later can text emergency services by satellite.")
          .font(Typeface.body(13))
          .foregroundStyle(Palette.muted)
      }
      .padding(20)
      .padding(.bottom, 100)
    }
    .background(Palette.paper)
    .sheet(isPresented: $showMessage) {
      MessageComposer(body: planText(coord: coord, back: turnAround, zone: zone))
    }
  }

  /// Distance back along the recorded track, or straight back to the trailhead.
  private var backDistance: Double {
    let recorder = app.recorder
    if recorder.distance > 0 {
      return recorder.distance
    }
    guard let here = recorder.location.map({ Coord($0.coordinate) }), let start = recorder.trail?.trailhead else {
      return 0
    }
    return here.distance(to: start)
  }

  private func coordinateText(_ coord: Coord) -> String {
    String(format: "%.4f° %@, %.4f° %@", abs(coord.lat), coord.lat >= 0 ? "N" : "S", abs(coord.lon), coord.lon >= 0 ? "E" : "W")
  }

  private func planText(coord: Coord, back: Date?, zone: TimeZone) -> String {
    let trail = app.recorder.trail?.name ?? "a hike"
    let park = app.recorder.park?.fullName ?? ""
    let time = back.map { " I plan to be back at the trailhead by about \(clockText($0.addingTimeInterval(app.recorder.distance / Self.defaultPace), zone))." } ?? ""
    return "I'm on \(trail) in \(park). Last position \(coordinateText(coord)) (https://maps.apple.com/?ll=\(coord.lat),\(coord.lon)).\(time)"
  }
}

private struct MessageComposer: UIViewControllerRepresentable {
  let body: String
  @Environment(\.dismiss) private var dismiss

  func makeCoordinator() -> Coordinator {
    Coordinator(dismiss: dismiss)
  }

  func makeUIViewController(context: Context) -> MFMessageComposeViewController {
    let controller = MFMessageComposeViewController()
    controller.body = body
    controller.messageComposeDelegate = context.coordinator
    return controller
  }

  func updateUIViewController(_ controller: MFMessageComposeViewController, context: Context) {}

  final class Coordinator: NSObject, MFMessageComposeViewControllerDelegate {
    let dismiss: DismissAction

    init(dismiss: DismissAction) {
      self.dismiss = dismiss
    }

    nonisolated func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
      MainActor.assumeIsolated { dismiss() }
    }
  }
}

// MARK: Postcard

struct PostcardView: View {
  @Environment(AppModel.self) private var app
  @Environment(\.modelContext) private var context
  let recordID: PersistentIdentifier
  @State private var photoItem: PhotosPickerItem?
  @State private var isWriting = false
  @State private var savedToPhotos = false

  var body: some View {
    if let record = context.model(for: recordID) as? HikeRecord {
      content(record)
    } else {
      ContentUnavailableView("Hike not found", systemImage: "photo")
    }
  }

  private func content(_ record: HikeRecord) -> some View {
    let card = PostcardArt(record: record, park: app.catalog.park(record.parkCode))
    return ScrollView {
      VStack(alignment: .leading, spacing: 16) {
        Eyebrow(text: "Postcard", color: Palette.rust)
        Text("From your hike · \(record.startedAt.formatted(date: .abbreviated, time: .omitted))").font(Typeface.body(14)).foregroundStyle(Palette.muted)
        card
        if isWriting {
          ProgressView("Writing a caption…").tint(Palette.forest)
        } else if app.writer.isAvailable {
          Label("Caption written on this iPhone", systemImage: "iphone").font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
        }
        HStack(spacing: 10) {
          Button("Rewrite") { Task { await write(record) } }
            .buttonStyle(SecondaryButtonStyle())
            .disabled(isWriting)
          PhotosPicker(selection: $photoItem, matching: .images) {
            Text(record.photo == nil ? "Add photo" : "Change photo")
              .font(Typeface.body(16, .bold))
              .foregroundStyle(Palette.forest)
              .frame(maxWidth: .infinity, minHeight: 52)
              .background(Capsule().fill(Palette.card))
              .overlay(Capsule().stroke(Palette.forest.opacity(0.35), lineWidth: 1.5))
          }
        }
        if let image = render(card) {
          ShareLink(item: Image(uiImage: image), preview: SharePreview("Greetings from \(record.trailName)", image: Image(uiImage: image))) {
            Label("Share", systemImage: "square.and.arrow.up")
          }
          .buttonStyle(PrimaryButtonStyle())
          Button(savedToPhotos ? "Saved to Photos" : "Save to Photos") {
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
            savedToPhotos = true
          }
          .buttonStyle(SecondaryButtonStyle())
          .disabled(savedToPhotos)
        }
      }
      .padding(20)
      .padding(.bottom, 100)
    }
    .background(Palette.paper)
    .task {
      if record.caption == nil {
        await write(record)
      }
    }
    .onChange(of: photoItem) { _, item in
      Task {
        if let data = try? await item?.loadTransferable(type: Data.self) {
          record.photo = data
          try? context.save()
        }
      }
    }
  }

  private func render(_ card: PostcardArt) -> UIImage? {
    let renderer = ImageRenderer(content: card.frame(width: 350))
    renderer.scale = 3
    return renderer.uiImage
  }

  private func write(_ record: HikeRecord) async {
    isWriting = true
    defer { isWriting = false }
    let zone = app.catalog.park(record.parkCode)?.zone ?? .current
    let light = app.catalog.park(record.parkCode).flatMap { app.daylight(for: $0, on: record.startedAt) }
    let facts = "Hike: \(record.trailName) in \(record.parkName). \(Units.miles(record.distance)), climbed \(Units.feet(record.climb)), \(Units.duration(record.movingSeconds)). Started \(clockText(record.startedAt, zone)), finished \(clockText(record.endedAt, zone)). Sunset that day \(clockText(light?.sunset, zone)), moon \(Int(((light?.moonIllumination ?? 0) * 100).rounded()))% lit."
    let instructions = "Write a warm, specific postcard caption of one or two sentences, under 30 words, in first person plural, about this hike. Mention the light or the moon only if the times fit. No hashtags, no emoji."
    let fallback = "\(Units.miles(record.distance)) on \(record.trailName), \(Units.feet(record.climb)) up. A good day in \(record.parkName)."
    record.caption = await app.writer.write(instructions: instructions, prompt: facts, maxTokens: 80) ?? fallback
    try? context.save()
  }
}

/// The postcard itself, also rendered to an image for sharing.
struct PostcardArt: View {
  let record: HikeRecord
  let park: ParkSummary?

  var body: some View {
    VStack(alignment: .leading, spacing: 0) {
      ZStack(alignment: .bottomLeading) {
        background
          .frame(height: 230)
          .clipped()
        VStack(alignment: .leading, spacing: 0) {
          Text("GREETINGS FROM").font(Typeface.body(12, .heavy)).tracking(2).foregroundStyle(Palette.gold)
          Text(record.trailName.uppercased()).font(Typeface.poster(40)).foregroundStyle(.white).lineLimit(2).minimumScaleFactor(0.5)
        }
        .padding(16)
      }
      VStack(alignment: .leading, spacing: 10) {
        Text(record.caption ?? " ").font(.system(size: 16, design: .serif).italic()).foregroundStyle(Palette.ink)
        HStack {
          Text("\(Units.miles(record.distance)) · +\(Units.feet(record.climb))").font(Typeface.body(13, .bold))
          Spacer()
          Text("\(Units.duration(record.movingSeconds)) · \(record.startedAt.formatted(.dateTime.day().month(.abbreviated).year()))").font(Typeface.body(13))
        }
        .foregroundStyle(Palette.muted)
      }
      .padding(16)
    }
    .background(Palette.card)
    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Palette.line, lineWidth: 1))
  }

  @ViewBuilder
  private var background: some View {
    if let data = record.photo, let image = UIImage(data: data) {
      Image(uiImage: image).resizable().scaledToFill()
        .overlay(LinearGradient(colors: [.clear, .black.opacity(0.5)], startPoint: .center, endPoint: .bottom))
    } else {
      ZStack {
        Palette.forest
        Circle().fill(Palette.gold).frame(width: 90, height: 90).offset(x: 90, y: -40)
        MountainGlyph().fill(Palette.deepForest).frame(height: 200).offset(y: 50)
        MountainGlyph().fill(Palette.rust.opacity(0.85)).frame(width: 260, height: 150).offset(x: -60, y: 70)
      }
    }
  }
}

// MARK: Journal

struct JournalView: View {
  @Environment(AppModel.self) private var app
  @Query(sort: \HikeRecord.startedAt, order: .reverse) private var hikes: [HikeRecord]

  var body: some View {
    let parks = Set(hikes.map(\.parkCode))
    let miles = hikes.reduce(0) { $0 + $1.distance } / 1609.34
    let weekAgo = Date().addingTimeInterval(-7 * 86400)
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        Eyebrow(text: "Journal", color: Palette.rust)
        Text("YOUR HIKES").font(Typeface.poster(56)).foregroundStyle(Palette.ink)
        Text("Kept on this iPhone").font(Typeface.body(14)).foregroundStyle(Palette.muted)
        HStack(spacing: 10) {
          stat("Parks", "\(parks.count) of \(app.catalog.parks.count)")
          stat("Hikes", "\(hikes.count)")
          stat("Miles", String(format: "%.1f", miles))
        }
        if !parks.isEmpty {
          Eyebrow(text: "Parks visited")
          LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
            ForEach(parks.sorted(), id: \.self) { code in
              if let park = app.catalog.park(code) {
                VStack(spacing: 6) {
                  Text(code.uppercased()).font(Typeface.poster(26)).foregroundStyle(Palette.card)
                  Text(park.name).font(Typeface.body(11, .bold)).foregroundStyle(Palette.card).lineLimit(1)
                }
                .frame(maxWidth: .infinity, minHeight: 84)
                .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(park.tint))
                .accessibilityElement(children: .combine)
              }
            }
          }
        }
        if hikes.isEmpty {
          Text("Start a hike from any trail and it shows up here, with a postcard.").font(Typeface.body(15)).foregroundStyle(Palette.muted)
        }
        let recent = hikes.filter { $0.startedAt > weekAgo }
        let earlier = hikes.filter { $0.startedAt <= weekAgo }
        section("This week", recent)
        section("Earlier", earlier)
      }
      .padding(20)
      .padding(.bottom, 100)
    }
    .background(Palette.paper)
    .toolbar(.hidden, for: .navigationBar)
  }

  private func stat(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(Typeface.body(12, .semibold)).foregroundStyle(Palette.muted)
      Text(value).font(Typeface.poster(28)).foregroundStyle(Palette.ink)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding(14)
    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Palette.card))
    .accessibilityElement(children: .combine)
  }

  @ViewBuilder
  private func section(_ title: String, _ list: [HikeRecord]) -> some View {
    if !list.isEmpty {
      Eyebrow(text: title)
      VStack(spacing: 0) {
        ForEach(list) { hike in
          NavigationLink(value: Route.postcard(hike.persistentModelID)) {
            HStack {
              VStack(alignment: .leading, spacing: 2) {
                Text(hike.trailName).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink)
                Text("\(hike.startedAt.formatted(.dateTime.weekday(.abbreviated).day().month(.abbreviated))) · \(hike.parkName)").font(Typeface.body(13)).foregroundStyle(Palette.muted)
                Text("\(Units.miles(hike.distance)) · +\(Units.feet(hike.climb)) · \(Units.duration(hike.movingSeconds))").font(Typeface.body(13)).foregroundStyle(Palette.muted)
              }
              Spacer()
              Image(systemName: "chevron.right").foregroundStyle(Palette.muted)
            }
            .frame(minHeight: 70)
            .contentShape(Rectangle())
            .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
          }
          .buttonStyle(.plain)
        }
      }
      .padding(.horizontal, 14)
      .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
    }
  }
}
