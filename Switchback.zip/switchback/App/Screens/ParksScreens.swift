import SwiftUI

/// A park's photo from the NPS when there is one; otherwise its colour and a mountain.
struct ParkPhoto: View {
  let park: ParkSummary
  var image: ParkImage?

  var body: some View {
    let source = (image ?? park.image)?.url.flatMap(URL.init(string:))
    ZStack {
      park.tint
      MountainGlyph().fill(Palette.card.opacity(0.25)).padding(40)
      if let source {
        AsyncImage(url: source) { phase in
          if let picture = phase.image {
            picture.resizable().scaledToFill()
          }
        }
      }
    }
    .clipped()
    .accessibilityHidden(true)
  }
}

func clockText(_ date: Date?, _ zone: TimeZone) -> String {
  date.map { $0.formatted(Date.FormatStyle(date: .omitted, time: .shortened, timeZone: zone)) } ?? "—"
}

// MARK: Welcome

struct WelcomeView: View {
  @Environment(AppModel.self) private var app
  @State private var query = ""

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        HStack(spacing: 8) {
          SwitchbackMark().stroke(Palette.rust, style: StrokeStyle(lineWidth: 2.4, lineCap: .round, lineJoin: .round)).frame(width: 24, height: 24)
          Text("SWITCHBACK").font(Typeface.label(16, .heavy)).tracking(1.3).foregroundStyle(Palette.forest)
        }
        .padding(.top, 24)
        Text("EVERY PARK.\nNO SIGNAL NEEDED.")
          .font(Typeface.poster(58))
          .foregroundStyle(Palette.ink)
          .lineSpacing(-6)
        VStack(alignment: .leading, spacing: 12) {
          feature("map", "Offline maps and trails for national parks")
          feature("bubble.left", "A ranger that answers right on your iPhone")
          feature("sun.horizon", "Golden hour and sunset at every viewpoint")
        }
        Eyebrow(text: "Choose your first park").padding(.top, 8)
        TextField("Search national parks", text: $query)
          .font(Typeface.body(16))
          .padding(.horizontal, 18)
          .frame(height: 50)
          .background(Capsule().fill(Palette.card))
          .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
        LazyVStack(spacing: 0) {
          ForEach(app.catalog.search(query)) { park in
            Button {
              app.hasOnboarded = true
              app.open(park)
            } label: {
              ParkRow(park: park)
            }
            .buttonStyle(.plain)
          }
        }
        Text("No account. Your hikes stay on this iPhone.")
          .font(Typeface.body(13))
          .foregroundStyle(Palette.muted)
          .padding(.bottom, 30)
      }
      .padding(.horizontal, 20)
    }
    .background(Palette.paper)
  }

  private func feature(_ symbol: String, _ text: String) -> some View {
    Label {
      Text(text).font(Typeface.body(16, .medium)).foregroundStyle(Palette.ink)
    } icon: {
      Image(systemName: symbol).foregroundStyle(Palette.rust).frame(width: 26)
    }
  }
}

struct ParkRow: View {
  @Environment(AppModel.self) private var app
  let park: ParkSummary

  var body: some View {
    HStack(spacing: 12) {
      ParkBadge(park: park)
      VStack(alignment: .leading, spacing: 1) {
        Text(park.name).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink)
        Text(park.stateNames).font(Typeface.body(13)).foregroundStyle(Palette.muted)
      }
      Spacer()
      if app.store.isReady(park.code) {
        Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.forest).accessibilityLabel("Ready offline")
      }
      Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundStyle(Palette.muted)
    }
    .frame(minHeight: 60)
    .contentShape(Rectangle())
    .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
  }
}

// MARK: Your parks

struct ParksHomeView: View {
  @Environment(AppModel.self) private var app
  @State private var query = ""

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        HStack {
          HStack(spacing: 8) {
            SwitchbackMark().stroke(Palette.rust, style: StrokeStyle(lineWidth: 2.2, lineCap: .round, lineJoin: .round)).frame(width: 22, height: 22)
            Text("SWITCHBACK").font(Typeface.label(16, .heavy)).tracking(1.3).foregroundStyle(Palette.forest)
          }
          Spacer()
        }
        Text("YOUR PARKS").font(Typeface.poster(60)).foregroundStyle(Palette.ink)
        NavigationLink(value: Route.explore("")) {
          HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
            Text("Search \(app.catalog.parks.count) national parks").foregroundStyle(Palette.muted)
            Spacer()
          }
          .font(Typeface.body(15))
          .padding(.horizontal, 18)
          .frame(height: 50)
          .background(Capsule().fill(Palette.card))
          .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
        }
        .buttonStyle(.plain)

        ForEach(app.yourParks) { park in
          NavigationLink(value: Route.park(park.code)) {
            ParkHero(park: park)
          }
          .buttonStyle(.plain)
        }

        let suggestions = app.catalog.parks.filter { !app.store.isReady($0.code) && $0.code != app.currentParkCode }.prefix(4)
        VStack(alignment: .leading, spacing: 10) {
          Eyebrow(text: "Download for offline")
          VStack(spacing: 0) {
            ForEach(Array(suggestions)) { park in
              HStack(spacing: 12) {
                NavigationLink(value: Route.park(park.code)) {
                  HStack(spacing: 12) {
                    ParkBadge(park: park)
                    VStack(alignment: .leading, spacing: 1) {
                      Text(park.name).font(Typeface.body(16, .semibold)).foregroundStyle(Palette.ink)
                      Text(park.stateNames).font(Typeface.body(13)).foregroundStyle(Palette.muted)
                    }
                    Spacer()
                  }
                  .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                NavigationLink(value: Route.download(park.code)) {
                  Image(systemName: "arrow.down.to.line").font(.system(size: 16, weight: .semibold))
                }
                .buttonStyle(RoundIconButtonStyle())
                .accessibilityLabel("Download \(park.name)")
              }
              .frame(minHeight: 60)
              .overlay(alignment: .top) { Rectangle().fill(Palette.line).frame(height: 1).opacity(park.id == suggestions.first?.id ? 0 : 1) }
            }
          }
          .padding(.horizontal, 14)
          .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.card))
          .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Palette.line, lineWidth: 1))
          Text("Maps, trails and the ranger guide all work with no signal.")
            .font(Typeface.body(13))
            .foregroundStyle(Palette.muted)
        }
      }
      .padding(.horizontal, 20)
      .padding(.top, 8)
      .padding(.bottom, 110)
    }
    .background(Palette.paper)
    .toolbar(.hidden, for: .navigationBar)
  }
}

struct ParkHero: View {
  @Environment(AppModel.self) private var app
  let park: ParkSummary

  var body: some View {
    ZStack(alignment: .bottomLeading) {
      ParkPhoto(park: park)
        .frame(height: 232)
        .overlay(LinearGradient(colors: [.clear, .black.opacity(0.55)], startPoint: .center, endPoint: .bottom))
      VStack(alignment: .leading, spacing: 8) {
        Text(park.name.uppercased()).font(Typeface.poster(44)).foregroundStyle(.white).lineLimit(2).minimumScaleFactor(0.6)
        HStack(spacing: 6) {
          if app.store.isReady(park.code) {
            Chip(text: "Ready offline", systemImage: "checkmark")
          } else if app.store.isDownloading(park.code) {
            Chip(text: "Saving \(Int((app.store.progress[park.code]?.fraction ?? 0) * 100))%", systemImage: "arrow.down")
          }
          if let sunset = app.daylight(for: park)?.sunset {
            Chip(text: "Sunset \(clockText(sunset, park.zone))", foreground: Palette.gold, background: Color(hex: 0x16352A).opacity(0.75))
          }
        }
      }
      .padding(18)
    }
    .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
    .accessibilityElement(children: .combine)
  }
}

// MARK: Explore

struct ExploreView: View {
  @Environment(AppModel.self) private var app
  @State private var query: String
  @State private var category: ParkCategory?
  @State private var nearMe = false

  init(initialQuery: String) {
    _query = State(initialValue: initialQuery)
  }

  var body: some View {
    let parks = sorted(app.catalog.search(query, in: category))
    ScrollView {
      VStack(alignment: .leading, spacing: 14) {
        Eyebrow(text: "Explore", color: Palette.rust)
        Text("\(app.catalog.parks.count) NATIONAL PARKS").font(Typeface.poster(44)).foregroundStyle(Palette.ink)
        HStack(spacing: 10) {
          Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
          TextField("Search parks or states", text: $query).font(Typeface.body(15))
        }
        .padding(.horizontal, 18)
        .frame(height: 50)
        .background(Capsule().fill(Palette.card))
        .overlay(Capsule().stroke(Palette.line, lineWidth: 1))
        ScrollView(.horizontal) {
          HStack(spacing: 8) {
            filter("All", selected: category == nil && !nearMe) {
              category = nil
              nearMe = false
            }
            filter("Near me", selected: nearMe) {
              nearMe.toggle()
              if nearMe {
                app.recorder.requestLocation()
              }
            }
            ForEach(ParkCategory.allCases) { option in
              filter(option.title, selected: category == option) {
                category = category == option ? nil : option
              }
            }
          }
        }
        .scrollIndicators(.hidden)
        LazyVStack(spacing: 0) {
          ForEach(parks) { park in
            NavigationLink(value: Route.park(park.code)) {
              ParkRow(park: park)
            }
            .buttonStyle(.plain)
          }
        }
      }
      .padding(.horizontal, 20)
      .padding(.bottom, 110)
    }
    .background(Palette.paper)
    .navigationBarTitleDisplayMode(.inline)
  }

  private func sorted(_ parks: [ParkSummary]) -> [ParkSummary] {
    guard nearMe, let here = app.recorder.location.map({ Coord($0.coordinate) }) else {
      return parks
    }
    return parks.sorted { lhs, rhs in
      let a = lhs.coordinate.map { Coord($0).distance(to: here) } ?? .infinity
      let b = rhs.coordinate.map { Coord($0).distance(to: here) } ?? .infinity
      return a < b
    }
  }

  private func filter(_ title: String, selected: Bool, action: @escaping () -> Void) -> some View {
    Button(action: action) {
      Text(title)
        .font(Typeface.body(14, .semibold))
        .foregroundStyle(selected ? Palette.card : Palette.ink)
        .padding(.horizontal, 16)
        .frame(height: 40)
        .background(Capsule().fill(selected ? Palette.forest : Palette.card))
        .overlay(Capsule().stroke(Palette.line, lineWidth: selected ? 0 : 1))
    }
    .buttonStyle(.plain)
    .accessibilityAddTraits(selected ? .isSelected : [])
  }
}
