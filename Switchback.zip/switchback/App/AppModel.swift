import Foundation
import Observation
import SkyKit
import SwiftData

enum Route: Hashable {
  case park(String)
  case trail(park: String, trail: String)
  case viewpoint(park: String, place: String)
  case explore(String)
  case download(String)
  case hike
  case safety
  case postcard(PersistentIdentifier)
}

@Observable
final class AppModel {
  enum Tab: Hashable {
    case parks
    case map
    case ranger
    case journal
  }

  let container = Storage.makeContainer()
  let catalog = Catalog()
  let store = ParkStore()
  let writer = Writer()
  let connectivity = Connectivity()
  let recorder = HikeRecorder()
  let ranger: Ranger

  var tab: Tab = .parks
  var parksPath: [Route] = []
  var mapPath: [Route] = []
  var journalPath: [Route] = []
  /// A trail the map should centre on next time it shows.
  var mapFocus: String?
  var rangerDraft: String?
  private var picks: [String: (key: String, text: String)] = [:]

  var currentParkCode: String? {
    didSet { UserDefaults.standard.set(currentParkCode, forKey: Keys.current) }
  }

  var hasOnboarded: Bool {
    didSet { UserDefaults.standard.set(hasOnboarded, forKey: Keys.onboarded) }
  }

  private enum Keys {
    static let current = "currentPark"
    static let onboarded = "hasOnboarded"
  }

  init() {
    ranger = Ranger(writer: writer)
    currentParkCode = UserDefaults.standard.string(forKey: Keys.current)
    hasOnboarded = UserDefaults.standard.bool(forKey: Keys.onboarded)
  }

  var currentPark: ParkSummary? {
    currentParkCode.flatMap(catalog.park)
  }

  /// Downloaded parks first, newest first, then the current park if it isn't one.
  var yourParks: [ParkSummary] {
    var codes = store.packs.values.sorted { $0.savedAt > $1.savedAt }.map(\.code)
    if let current = currentParkCode, !codes.contains(current) {
      codes.insert(current, at: 0)
    }
    return codes.compactMap(catalog.park)
  }

  // MARK: Navigation

  func open(_ park: ParkSummary) {
    currentParkCode = park.code
    tab = .parks
    parksPath.append(.park(park.code))
  }

  func showOnMap(_ park: ParkSummary, trail: String? = nil) {
    currentParkCode = park.code
    mapFocus = trail
    tab = .map
  }

  func ask(_ question: String, about park: ParkSummary) {
    currentParkCode = park.code
    rangerDraft = question
    tab = .ranger
  }

  func startHike(_ park: ParkSummary, trail: Trail?) {
    recorder.start(park: park, trail: trail)
    currentParkCode = park.code
    tab = .map
    mapPath = [.hike]
  }

  func finishHike() -> HikeRecord? {
    guard let finished = recorder.finish() else {
      return nil
    }
    let record = HikeRecord(
      parkCode: finished.park.code,
      parkName: finished.park.name,
      trailName: finished.trailName,
      startedAt: finished.startedAt,
      endedAt: finished.endedAt,
      distance: finished.distance,
      climb: finished.climb,
      movingSeconds: finished.movingSeconds,
      track: finished.track
    )
    container.mainContext.insert(record)
    try? container.mainContext.save()
    return record
  }

  // MARK: Trails and the guide

  /// The park guide's write-up of a trail, matched by name.
  func guideHike(for trail: Trail, in code: String) -> GuideItem? {
    let name = ParkStore.normalize(trail.name)
    guard !name.isEmpty else {
      return nil
    }
    return catalog.guide(code)?.hikes.first { hike in
      let title = ParkStore.normalize(hike.title)
      return !title.isEmpty && (title.contains(name) || name.contains(title))
    }
  }

  /// The hike's distance: the guide's own figure when it gives one, otherwise the mapped route.
  func hikeDistance(_ trail: Trail, in code: String) -> (meters: Double, isLoop: Bool, fromGuide: Bool) {
    if let hike = guideHike(for: trail, in: code), let stated = GuideDistance.parse(hike.summary + " " + hike.body) {
      return (stated.meters, stated.isLoop, true)
    }
    return (trail.roundTrip, trail.isLoop, false)
  }

  // MARK: Light

  func daylight(for park: ParkSummary, on date: Date = Date()) -> Daylight? {
    guard let lat = park.lat, let lon = park.lon else {
      return nil
    }
    return DaylightCalculator.day(containing: date, latitude: lat, longitude: lon, timeZone: park.zone)
  }

  func daylight(at coord: Coord, zone: TimeZone, on date: Date = Date()) -> Daylight {
    DaylightCalculator.day(containing: date, latitude: coord.lat, longitude: coord.lon, timeZone: zone)
  }

  // MARK: Ranger's pick

  /// One suggestion for the rest of today, written once per park per few hours.
  func rangersPick(for park: ParkSummary) async -> String {
    let hour = Calendar.current.component(.hour, from: Date()) / 3
    let key = "\(Date().formatted(.dateTime.year().month().day()))-\(hour)"
    if let cached = picks[park.code], cached.key == key {
      return cached.text
    }
    let fallback = fallbackPick(for: park)
    let trails = (store.packs[park.code]?.trails ?? [])
      .filter { $0.profile != nil && $0.roundTrip < 12_000 }
      .sorted { $0.roundTrip < $1.roundTrip }
      .prefix(8)
      .map { "\($0.name): \(Units.miles($0.roundTrip)) round trip, \($0.climb.map(Units.feet) ?? "unknown") climb, \(Units.hours($0.estimatedHours))" }
    let hikes = (catalog.guide(park.code)?.hikes ?? []).prefix(8).map { "\($0.title): \($0.duration). \($0.summary.prefix(160))" }
    let views = (catalog.guide(park.code)?.viewpoints ?? []).prefix(6).map(\.title)
    let prompt = """
    \(Ranger.todayText(park))
    Trails: \(trails.joined(separator: "; "))
    Guide hikes: \(hikes.joined(separator: "; "))
    Viewpoints: \(views.joined(separator: ", "))
    Suggest one outing for the rest of today.
    """
    let instructions = "You are a park ranger. In two or three short sentences, suggest one specific outing for the rest of today using only the facts given, with real times (for example when to leave to catch golden hour). If it is already dark, suggest something for tomorrow morning. No lists, no emoji."
    let text = await writer.write(instructions: instructions, prompt: prompt, maxTokens: 140) ?? fallback
    picks[park.code] = (key, text)
    return text
  }

  private func fallbackPick(for park: ParkSummary) -> String {
    guard let light = daylight(for: park), let golden = light.eveningGoldenStart else {
      return "Ask the ranger what's good today."
    }
    let time = golden.formatted(Date.FormatStyle(date: .omitted, time: .shortened, timeZone: park.zone))
    if let view = catalog.guide(park.code)?.viewpoints.first {
      return "Golden light starts at \(time). \(view.title) is a good place to be for it."
    }
    return "Golden light starts at \(time) today."
  }
}
