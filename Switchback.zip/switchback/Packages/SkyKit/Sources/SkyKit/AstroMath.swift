import Foundation

// Angles are degrees everywhere in SkyKit's public API; radians stay inside these helpers.

@inline(__always) public func radians(_ degrees: Double) -> Double { degrees * .pi / 180 }
@inline(__always) public func degrees(_ radians: Double) -> Double { radians * 180 / .pi }
@inline(__always) public func sind(_ x: Double) -> Double { sin(radians(x)) }
@inline(__always) public func cosd(_ x: Double) -> Double { cos(radians(x)) }
@inline(__always) public func atan2d(_ y: Double, _ x: Double) -> Double { degrees(atan2(y, x)) }
@inline(__always) public func asind(_ x: Double) -> Double { degrees(asin(min(1, max(-1, x)))) }
@inline(__always) public func acosd(_ x: Double) -> Double { degrees(acos(min(1, max(-1, x)))) }

/// Wraps an angle into 0..<360.
public func wrap360(_ x: Double) -> Double {
  let r = x.truncatingRemainder(dividingBy: 360)
  return r < 0 ? r + 360 : r
}

/// Wraps an angle into -180..<180.
public func wrap180(_ x: Double) -> Double {
  let r = wrap360(x)
  return r >= 180 ? r - 360 : r
}

public struct Vector3: Sendable, Hashable {
  public var x: Double
  public var y: Double
  public var z: Double

  public init(_ x: Double, _ y: Double, _ z: Double) {
    self.x = x
    self.y = y
    self.z = z
  }

  /// A unit vector from a longitude (right ascension or azimuth-like angle) and latitude.
  public static func spherical(lon: Double, lat: Double) -> Vector3 {
    let cosLat = cosd(lat)
    return Vector3(cosLat * cosd(lon), cosLat * sind(lon), sind(lat))
  }

  public var length: Double { (x * x + y * y + z * z).squareRoot() }

  public var normalized: Vector3 {
    let l = length
    return l > 0 ? Vector3(x / l, y / l, z / l) : self
  }

  public func dot(_ o: Vector3) -> Double { x * o.x + y * o.y + z * o.z }

  public func cross(_ o: Vector3) -> Vector3 {
    Vector3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
  }

  public static func + (a: Vector3, b: Vector3) -> Vector3 { Vector3(a.x + b.x, a.y + b.y, a.z + b.z) }
  public static func - (a: Vector3, b: Vector3) -> Vector3 { Vector3(a.x - b.x, a.y - b.y, a.z - b.z) }
  public static func * (a: Vector3, k: Double) -> Vector3 { Vector3(a.x * k, a.y * k, a.z * k) }
  public static prefix func - (a: Vector3) -> Vector3 { Vector3(-a.x, -a.y, -a.z) }
}

/// A 3×3 matrix stored as rows.
public struct Matrix3: Sendable {
  public var r0: Vector3
  public var r1: Vector3
  public var r2: Vector3

  public init(_ r0: Vector3, _ r1: Vector3, _ r2: Vector3) {
    self.r0 = r0
    self.r1 = r1
    self.r2 = r2
  }

  public static let identity = Matrix3(Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1))

  public func apply(_ v: Vector3) -> Vector3 { Vector3(r0.dot(v), r1.dot(v), r2.dot(v)) }

  public var transposed: Matrix3 {
    Matrix3(Vector3(r0.x, r1.x, r2.x), Vector3(r0.y, r1.y, r2.y), Vector3(r0.z, r1.z, r2.z))
  }

  public static func * (a: Matrix3, b: Matrix3) -> Matrix3 {
    let t = b.transposed
    return Matrix3(
      Vector3(a.r0.dot(t.r0), a.r0.dot(t.r1), a.r0.dot(t.r2)),
      Vector3(a.r1.dot(t.r0), a.r1.dot(t.r1), a.r1.dot(t.r2)),
      Vector3(a.r2.dot(t.r0), a.r2.dot(t.r1), a.r2.dot(t.r2))
    )
  }

  /// Rotation about the z axis that adds `angle` to longitudes.
  static func rotationZ(_ angle: Double) -> Matrix3 {
    let c = cosd(angle)
    let s = sind(angle)
    return Matrix3(Vector3(c, -s, 0), Vector3(s, c, 0), Vector3(0, 0, 1))
  }
}

/// Right ascension and declination in degrees.
public struct Equatorial: Sendable, Hashable {
  public var ra: Double
  public var dec: Double

  public init(ra: Double, dec: Double) {
    self.ra = wrap360(ra)
    self.dec = dec
  }

  public init(_ v: Vector3) {
    ra = wrap360(atan2d(v.y, v.x))
    dec = asind(v.z / max(v.length, .leastNonzeroMagnitude))
  }

  public var vector: Vector3 { .spherical(lon: ra, lat: dec) }

  /// Angular distance in degrees.
  public func separation(from other: Equatorial) -> Double {
    acosd(vector.dot(other.vector))
  }
}

/// Altitude above the horizon and azimuth from north through east, in degrees.
public struct Horizontal: Sendable, Hashable {
  public var altitude: Double
  public var azimuth: Double

  public init(altitude: Double, azimuth: Double) {
    self.altitude = altitude
    self.azimuth = wrap360(azimuth)
  }

  /// From an east-north-up unit vector.
  public init(enu v: Vector3) {
    altitude = asind(v.z)
    azimuth = wrap360(atan2d(v.x, v.y))
  }

  /// East-north-up unit vector.
  public var enu: Vector3 {
    let c = cosd(altitude)
    return Vector3(c * sind(azimuth), c * cosd(azimuth), sind(altitude))
  }

  public func separation(from other: Horizontal) -> Double {
    acosd(enu.dot(other.enu))
  }
}

/// Where someone is standing. Longitude is positive east.
public struct Observer: Sendable, Hashable, Codable {
  public var latitude: Double
  public var longitude: Double
  public var timeZoneIdentifier: String

  public init(latitude: Double, longitude: Double, timeZone: TimeZone = .current) {
    self.latitude = latitude
    self.longitude = longitude
    timeZoneIdentifier = timeZone.identifier
  }

  public var timeZone: TimeZone { TimeZone(identifier: timeZoneIdentifier) ?? .current }
}

public enum AstroTime {
  public static func julianDay(_ date: Date) -> Double {
    date.timeIntervalSince1970 / 86_400 + 2_440_587.5
  }

  /// Julian centuries since J2000.0.
  static func centuries(_ date: Date) -> Double {
    (julianDay(date) - 2_451_545.0) / 36_525
  }

  /// Days since 2000 Jan 0.0 UT, the time argument of the orbital elements in `SolarSystem`.
  static func dayNumber(_ date: Date) -> Double {
    julianDay(date) - 2_451_543.5
  }

  /// Local sidereal time in degrees.
  public static func localSiderealTime(_ date: Date, longitude: Double) -> Double {
    let jd = julianDay(date)
    let t = (jd - 2_451_545.0) / 36_525
    let gmst = 280.460_618_37 + 360.985_647_366_29 * (jd - 2_451_545.0) + 0.000_387_933 * t * t - t * t * t / 38_710_000
    return wrap360(gmst + longitude)
  }

  static func obliquity(dayNumber d: Double) -> Double {
    23.4393 - 3.563e-7 * d
  }
}

public enum Transform {
  /// Precession from J2000 to the equinox of `date` (IAU 1976, Meeus ch. 21). Planet positions in
  /// `SolarSystem` are already of date; catalog positions are J2000.
  public static func precession(to date: Date) -> Matrix3 {
    let t = AstroTime.centuries(date)
    let zeta = (2306.2181 * t + 0.30188 * t * t + 0.017998 * t * t * t) / 3600
    let z = (2306.2181 * t + 1.09468 * t * t + 0.018203 * t * t * t) / 3600
    let theta = (2004.3109 * t - 0.42665 * t * t - 0.041833 * t * t * t) / 3600
    let c = cosd(theta)
    let s = sind(theta)
    let tilt = Matrix3(Vector3(c, 0, -s), Vector3(0, 1, 0), Vector3(s, 0, c))
    return Matrix3.rotationZ(z) * tilt * Matrix3.rotationZ(zeta)
  }

  /// Equatorial (of date) to east-north-up for an observer at `date`.
  public static func horizon(for observer: Observer, at date: Date) -> Matrix3 {
    let lst = AstroTime.localSiderealTime(date, longitude: observer.longitude)
    let sl = sind(lst)
    let cl = cosd(lst)
    let sp = sind(observer.latitude)
    let cp = cosd(observer.latitude)
    return Matrix3(
      Vector3(-sl, cl, 0),
      Vector3(-sp * cl, -sp * sl, cp),
      Vector3(cp * cl, cp * sl, sp)
    )
  }

  public static func horizontal(_ position: Equatorial, observer: Observer, at date: Date) -> Horizontal {
    Horizontal(enu: horizon(for: observer, at: date).apply(position.vector))
  }

  /// Atmospheric refraction in degrees for a true altitude (Sæmundsson). Objects appear higher.
  public static func refraction(atTrueAltitude h: Double) -> Double {
    guard h > -1.5 else {
      return 0
    }
    return 1.02 / tan(radians(h + 10.3 / (h + 5.11))) / 60
  }
}
