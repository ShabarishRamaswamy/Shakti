import Foundation

public enum Planet: String, CaseIterable, Sendable, Codable {
  case mercury
  case venus
  case mars
  case jupiter
  case saturn
  case uranus
  case neptune

  public var name: String { rawValue.capitalized }
}

public struct BodyPosition: Sendable {
  /// Geocentric, equinox of date.
  public let equatorial: Equatorial
  public let magnitude: Double
  /// Illuminated fraction of the disc, 0…1.
  public let illumination: Double
  /// Distance from Earth in kilometres.
  public let distanceKm: Double
  /// Horizontal parallax in degrees; only the Moon's is big enough to matter.
  public let parallax: Double
}

public struct MoonPhase: Sendable {
  public let illumination: Double
  public let isWaxing: Bool
  /// Degrees the Moon is ahead of the Sun: 0 new, 90 first quarter, 180 full, 270 last quarter.
  public let age: Double

  public init(illumination: Double, isWaxing: Bool, age: Double) {
    self.illumination = illumination
    self.isWaxing = isWaxing
    self.age = age
  }

  /// Sun–Earth–Moon angle, 0…180 whichever way the Moon is heading.
  public var elongation: Double { age > 180 ? 360 - age : age }

  public var name: String {
    switch elongation {
    case ..<10: "New Moon"
    case ..<80: isWaxing ? "Waxing crescent" : "Waning crescent"
    case ..<100: isWaxing ? "First quarter" : "Last quarter"
    case ..<170: isWaxing ? "Waxing gibbous" : "Waning gibbous"
    default: "Full Moon"
    }
  }
}

/// Sun, Moon and planet positions from mean orbital elements with the main perturbation terms
/// (Paul Schlyter, "How to compute planetary positions"). Good to about an arcminute or two for
/// the planets and a few arcminutes for the Moon, far finer than anything an eye or a phone sees.
public enum SolarSystem {
  private static let kmPerAU = 149_597_870.7
  private static let earthRadiusKm = 6378.14

  private struct Elements {
    let n: Double
    let i: Double
    let w: Double
    let a: Double
    let e: Double
    let m: Double
  }

  private struct Heliocentric {
    var lon: Double
    var lat: Double
    var r: Double

    var vector: Vector3 { Vector3.spherical(lon: lon, lat: lat) * r }
  }

  // MARK: Sun

  /// The Sun's geocentric ecliptic longitude and distance (AU).
  private static func sunEcliptic(_ d: Double) -> (lon: Double, r: Double, meanAnomaly: Double, meanLongitude: Double) {
    let w = 282.9404 + 4.70935e-5 * d
    let e = 0.016709 - 1.151e-9 * d
    let m = wrap360(356.0470 + 0.9856002585 * d)
    let (v, r) = trueAnomaly(meanAnomaly: m, eccentricity: e, semiMajorAxis: 1)
    return (wrap360(v + w), r, m, wrap360(m + w))
  }

  public static func sun(at date: Date) -> BodyPosition {
    let d = AstroTime.dayNumber(date)
    let sun = sunEcliptic(d)
    let ecliptic = Vector3.spherical(lon: sun.lon, lat: 0) * sun.r
    return BodyPosition(
      equatorial: Equatorial(toEquatorial(ecliptic, d: d)),
      magnitude: -26.7,
      illumination: 1,
      distanceKm: sun.r * kmPerAU,
      parallax: 0
    )
  }

  // MARK: Moon

  public static func moon(at date: Date) -> BodyPosition {
    let d = AstroTime.dayNumber(date)
    let (moon, _) = moonEcliptic(d)
    let sun = sunEcliptic(d)
    let phase = moonPhase(moonLon: moon.lon, moonLat: moon.lat, sunLon: sun.lon)
    let phaseAngle = 180 - phase.elongation
    let rAU = moon.r * earthRadiusKm / kmPerAU
    let magnitude = 0.23 + 5 * log10(sun.r * rAU) + 0.026 * phaseAngle + 4.0e-9 * pow(phaseAngle, 4)
    return BodyPosition(
      equatorial: Equatorial(toEquatorial(moon.vector, d: d)),
      magnitude: magnitude,
      illumination: phase.illumination,
      distanceKm: moon.r * earthRadiusKm,
      parallax: asind(1 / moon.r)
    )
  }

  public static func moonPhase(at date: Date) -> MoonPhase {
    let d = AstroTime.dayNumber(date)
    let (moon, _) = moonEcliptic(d)
    let sun = sunEcliptic(d)
    return moonPhase(moonLon: moon.lon, moonLat: moon.lat, sunLon: sun.lon)
  }

  /// Degrees the Moon is ahead of the Sun in longitude, 0…360 (0 new, 180 full).
  static func moonAge(at date: Date) -> Double {
    let d = AstroTime.dayNumber(date)
    return wrap360(moonEcliptic(d).0.lon - sunEcliptic(d).lon)
  }

  private static func moonPhase(moonLon: Double, moonLat: Double, sunLon: Double) -> MoonPhase {
    let elongation = acosd(cosd(sunLon - moonLon) * cosd(moonLat))
    let phaseAngle = 180 - elongation
    let isWaxing = wrap360(moonLon - sunLon) < 180
    return MoonPhase(
      illumination: (1 + cosd(phaseAngle)) / 2,
      isWaxing: isWaxing,
      age: isWaxing ? elongation : 360 - elongation
    )
  }

  /// Geocentric ecliptic position of the Moon; distance in Earth radii.
  private static func moonEcliptic(_ d: Double) -> (Heliocentric, Double) {
    let el = Elements(
      n: wrap360(125.1228 - 0.0529538083 * d),
      i: 5.1454,
      w: wrap360(318.0634 + 0.1643573223 * d),
      a: 60.2666,
      e: 0.054900,
      m: wrap360(115.3654 + 13.0649929509 * d)
    )
    var pos = orbitPosition(el)
    let sun = sunEcliptic(d)
    let ms = sun.meanAnomaly
    let mm = el.m
    let lm = wrap360(el.n + el.w + el.m)
    let dd = wrap360(lm - sun.meanLongitude)
    let f = wrap360(lm - el.n)
    pos.lon += -1.274 * sind(mm - 2 * dd)
      + 0.658 * sind(2 * dd)
      - 0.186 * sind(ms)
      - 0.059 * sind(2 * mm - 2 * dd)
      - 0.057 * sind(mm - 2 * dd + ms)
      + 0.053 * sind(mm + 2 * dd)
      + 0.046 * sind(2 * dd - ms)
      + 0.041 * sind(mm - ms)
      - 0.035 * sind(dd)
      - 0.031 * sind(mm + ms)
      - 0.015 * sind(2 * f - 2 * dd)
      + 0.011 * sind(mm - 4 * dd)
    pos.lat += -0.173 * sind(f - 2 * dd)
      - 0.055 * sind(mm - f - 2 * dd)
      - 0.046 * sind(mm + f - 2 * dd)
      + 0.033 * sind(f + 2 * dd)
      + 0.017 * sind(2 * mm + f)
    pos.r += -0.58 * cosd(mm - 2 * dd) - 0.46 * cosd(2 * dd)
    pos.lon = wrap360(pos.lon)
    return (pos, d)
  }

  // MARK: Planets

  private static func elements(_ planet: Planet, d: Double) -> Elements {
    switch planet {
    case .mercury:
      Elements(n: 48.3313 + 3.24587e-5 * d, i: 7.0047 + 5.00e-8 * d, w: 29.1241 + 1.01444e-5 * d,
               a: 0.387098, e: 0.205635 + 5.59e-10 * d, m: 168.6562 + 4.0923344368 * d)
    case .venus:
      Elements(n: 76.6799 + 2.46590e-5 * d, i: 3.3946 + 2.75e-8 * d, w: 54.8910 + 1.38374e-5 * d,
               a: 0.723330, e: 0.006773 - 1.302e-9 * d, m: 48.0052 + 1.6021302244 * d)
    case .mars:
      Elements(n: 49.5574 + 2.11081e-5 * d, i: 1.8497 - 1.78e-8 * d, w: 286.5016 + 2.92961e-5 * d,
               a: 1.523688, e: 0.093405 + 2.516e-9 * d, m: 18.6021 + 0.5240207766 * d)
    case .jupiter:
      Elements(n: 100.4542 + 2.76854e-5 * d, i: 1.3030 - 1.557e-7 * d, w: 273.8777 + 1.64505e-5 * d,
               a: 5.20256, e: 0.048498 + 4.469e-9 * d, m: 19.8950 + 0.0830853001 * d)
    case .saturn:
      Elements(n: 113.6634 + 2.38980e-5 * d, i: 2.4886 - 1.081e-7 * d, w: 339.3939 + 2.97661e-5 * d,
               a: 9.55475, e: 0.055546 - 9.499e-9 * d, m: 316.9670 + 0.0334442282 * d)
    case .uranus:
      Elements(n: 74.0005 + 1.3978e-5 * d, i: 0.7733 + 1.9e-8 * d, w: 96.6612 + 3.0565e-5 * d,
               a: 19.18171 - 1.55e-8 * d, e: 0.047318 + 7.45e-9 * d, m: 142.5905 + 0.011725806 * d)
    case .neptune:
      Elements(n: 131.7806 + 3.0173e-5 * d, i: 1.7700 - 2.55e-7 * d, w: 272.8461 - 6.027e-6 * d,
               a: 30.05826 + 3.313e-8 * d, e: 0.008606 + 2.15e-9 * d, m: 260.2471 + 0.005995147 * d)
    }
  }

  public static func planet(_ planet: Planet, at date: Date) -> BodyPosition {
    let d = AstroTime.dayNumber(date)
    var helio = orbitPosition(elements(planet, d: d))
    applyPerturbations(to: &helio, planet: planet, d: d)

    let sun = sunEcliptic(d)
    let sunVector = Vector3.spherical(lon: sun.lon, lat: 0) * sun.r
    let geocentric = helio.vector + sunVector
    let distance = geocentric.length
    let phaseAngle = acosd((helio.r * helio.r + distance * distance - sun.r * sun.r) / (2 * helio.r * distance))
    var magnitude = baseMagnitude(planet, phaseAngle: phaseAngle) + 5 * log10(helio.r * distance)
    if planet == .saturn {
      magnitude += ringMagnitude(geocentric: geocentric, d: d)
    }
    return BodyPosition(
      equatorial: Equatorial(toEquatorial(geocentric, d: d)),
      magnitude: magnitude,
      illumination: (1 + cosd(phaseAngle)) / 2,
      distanceKm: distance * kmPerAU,
      parallax: 0
    )
  }

  /// How far Saturn's rings tilt toward Earth, in degrees (0 = edge-on).
  public static func saturnRingTilt(at date: Date) -> Double {
    let d = AstroTime.dayNumber(date)
    var helio = orbitPosition(elements(.saturn, d: d))
    applyPerturbations(to: &helio, planet: .saturn, d: d)
    let sun = sunEcliptic(d)
    let geocentric = helio.vector + Vector3.spherical(lon: sun.lon, lat: 0) * sun.r
    return ringTilt(geocentric: geocentric, d: d)
  }

  private static func baseMagnitude(_ planet: Planet, phaseAngle fv: Double) -> Double {
    switch planet {
    case .mercury: -0.36 + 0.027 * fv + 2.2e-13 * pow(fv, 6)
    case .venus: -4.34 + 0.013 * fv + 4.2e-7 * pow(fv, 3)
    case .mars: -1.51 + 0.016 * fv
    case .jupiter: -9.25 + 0.014 * fv
    case .saturn: -9.0 + 0.044 * fv
    case .uranus: -7.15 + 0.001 * fv
    case .neptune: -6.90 + 0.001 * fv
    }
  }

  private static func ringTilt(geocentric: Vector3, d: Double) -> Double {
    let lon = atan2d(geocentric.y, geocentric.x)
    let lat = asind(geocentric.z / geocentric.length)
    let ir = 28.06
    let nr = 169.51 + 3.82e-5 * d
    return asind(sind(lat) * cosd(ir) - cosd(lat) * sind(ir) * sind(lon - nr))
  }

  private static func ringMagnitude(geocentric: Vector3, d: Double) -> Double {
    let b = ringTilt(geocentric: geocentric, d: d)
    return -2.6 * sind(abs(b)) + 1.2 * sind(b) * sind(b)
  }

  private static func applyPerturbations(to pos: inout Heliocentric, planet: Planet, d: Double) {
    let mj = wrap360(19.8950 + 0.0830853001 * d)
    let ms = wrap360(316.9670 + 0.0334442282 * d)
    let mu = wrap360(142.5905 + 0.011725806 * d)
    switch planet {
    case .jupiter:
      pos.lon += -0.332 * sind(2 * mj - 5 * ms - 67.6)
        - 0.056 * sind(2 * mj - 2 * ms + 21)
        + 0.042 * sind(3 * mj - 5 * ms + 21)
        - 0.036 * sind(mj - 2 * ms)
        + 0.022 * cosd(mj - ms)
        + 0.023 * sind(2 * mj - 3 * ms + 52)
        - 0.016 * sind(mj - 5 * ms - 69)
    case .saturn:
      pos.lon += 0.812 * sind(2 * mj - 5 * ms - 67.6)
        - 0.229 * cosd(2 * mj - 4 * ms - 2)
        + 0.119 * sind(mj - 2 * ms - 3)
        + 0.046 * sind(2 * mj - 6 * ms - 69)
        + 0.014 * sind(mj - 3 * ms + 32)
      pos.lat += -0.020 * cosd(2 * mj - 4 * ms - 2) + 0.018 * sind(2 * mj - 6 * ms - 49)
    case .uranus:
      pos.lon += 0.040 * sind(ms - 2 * mu + 6)
        + 0.035 * sind(ms - 3 * mu + 33)
        - 0.015 * sind(mj - mu + 20)
    default:
      break
    }
  }

  // MARK: Orbits

  private static func trueAnomaly(meanAnomaly m: Double, eccentricity e: Double, semiMajorAxis a: Double) -> (v: Double, r: Double) {
    let mr = radians(wrap360(m))
    var ecc = mr + e * sin(mr) * (1 + e * cos(mr))
    for _ in 0..<12 {
      let delta = (ecc - e * sin(ecc) - mr) / (1 - e * cos(ecc))
      ecc -= delta
      if abs(delta) < 1e-10 {
        break
      }
    }
    let xv = a * (cos(ecc) - e)
    let yv = a * (1 - e * e).squareRoot() * sin(ecc)
    return (degrees(atan2(yv, xv)), (xv * xv + yv * yv).squareRoot())
  }

  /// Ecliptic position (equinox of date) from orbital elements.
  private static func orbitPosition(_ el: Elements) -> Heliocentric {
    let (v, r) = trueAnomaly(meanAnomaly: el.m, eccentricity: el.e, semiMajorAxis: el.a)
    let vw = v + el.w
    let x = r * (cosd(el.n) * cosd(vw) - sind(el.n) * sind(vw) * cosd(el.i))
    let y = r * (sind(el.n) * cosd(vw) + cosd(el.n) * sind(vw) * cosd(el.i))
    let z = r * sind(vw) * sind(el.i)
    return Heliocentric(lon: wrap360(atan2d(y, x)), lat: atan2d(z, (x * x + y * y).squareRoot()), r: r)
  }

  private static func toEquatorial(_ ecliptic: Vector3, d: Double) -> Vector3 {
    let ecl = AstroTime.obliquity(dayNumber: d)
    return Vector3(
      ecliptic.x,
      ecliptic.y * cosd(ecl) - ecliptic.z * sind(ecl),
      ecliptic.y * sind(ecl) + ecliptic.z * cosd(ecl)
    )
  }
}
