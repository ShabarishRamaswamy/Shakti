import Foundation

/// Plain-language directions: what someone standing outside can actually use.
public enum Directions {
  private static let points16 = [
    "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"
  ]
  private static let words8 = [
    "north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest"
  ]

  /// "SE".
  public static func compassPoint(_ azimuth: Double) -> String {
    points16[Int((wrap360(azimuth) + 11.25) / 22.5) % 16]
  }

  /// "southeast".
  public static func compassWord(_ azimuth: Double) -> String {
    words8[Int((wrap360(azimuth) + 22.5) / 45) % 8]
  }

  /// "low", "halfway up", "high", "almost overhead".
  public static func height(_ altitude: Double) -> String {
    switch altitude {
    case ..<0: "below the horizon"
    case ..<10: "just above the horizon"
    case ..<28: "low"
    case ..<55: "halfway up"
    case ..<75: "high"
    default: "almost overhead"
    }
  }

  /// "Southeast, halfway up".
  public static func whereToLook(_ horizontal: Horizontal) -> String {
    guard horizontal.altitude < 80 else {
      return "Almost straight overhead"
    }
    return "\(compassWord(horizontal.azimuth).capitalized), \(height(horizontal.altitude))"
  }

  /// How a separation looks at arm's length: a fingertip is about 1°, a fist about 10°.
  public static func handMeasure(_ degrees: Double) -> String {
    switch degrees {
    case ..<2.5: "about a fingertip apart"
    case ..<6: "about three fingers apart"
    case ..<8.5: "a bit less than a fist at arm's length"
    case ..<12: "about a fist at arm's length"
    case ..<17: "about a fist and a half"
    case ..<25: "about a hand span"
    default: "\(Int(degrees.rounded()))° apart"
    }
  }

  /// Where `object` sits relative to `reference` for someone facing it: "below-left".
  public static func relativePosition(of object: Horizontal, from reference: Horizontal) -> String {
    let dx = wrap180(object.azimuth - reference.azimuth) * cosd(reference.altitude)
    let dy = object.altitude - reference.altitude
    let length = max((dx * dx + dy * dy).squareRoot(), 0.0001)
    let vertical = abs(dy) / length > 0.38 ? (dy < 0 ? "below" : "above") : nil
    let horizontal = abs(dx) / length > 0.38 ? (dx < 0 ? "left" : "right") : nil
    switch (vertical, horizontal) {
    case let (v?, h?): return "\(v)-\(h)"
    case let (v?, nil): return v
    case let (nil, h?): return "to the \(h)"
    default: return "next to"
    }
  }

  public static func degrees(_ value: Double) -> String {
    "\(Int(value.rounded()))°"
  }
}
