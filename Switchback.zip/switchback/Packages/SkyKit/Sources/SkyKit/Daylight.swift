import Foundation

/// The light over one place for one calendar day: sunrise and sunset, golden and blue hours,
/// last light, and the Moon.
public struct Daylight: Sendable {
  public let sunrise: Date?
  public let sunset: Date?
  public let solarNoon: Date?
  /// Morning golden hour ends when the Sun climbs past 6°; evening golden hour starts there.
  public let morningGoldenEnd: Date?
  public let eveningGoldenStart: Date?
  /// Golden light lasts until the Sun is 4° below the horizon; blue hour runs on to -6°.
  public let eveningGoldenEnd: Date?
  public let morningGoldenStart: Date?
  /// Civil dawn and dusk: the first and last light good enough to walk by.
  public let firstLight: Date?
  public let lastLight: Date?
  public let moonrise: Date?
  public let moonset: Date?
  public let moonIllumination: Double
  public let moonWaxing: Bool

  public var isMoonFull: Bool { moonIllumination > 0.97 }
}

public enum DaylightCalculator {
  private static let step: TimeInterval = 10 * 60
  /// Standard altitudes for rise and set, refraction and the disc's radius included.
  private static let horizon = -0.833
  private static let goldenTop = 6.0
  private static let goldenBottom = -4.0
  private static let civil = -6.0

  public static func day(containing date: Date, latitude: Double, longitude: Double, timeZone: TimeZone) -> Daylight {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = timeZone
    let start = calendar.startOfDay(for: date)
    let end = calendar.date(byAdding: .day, value: 1, to: start) ?? start.addingTimeInterval(86_400)
    let window = DateInterval(start: start, end: end)
    let observer = Observer(latitude: latitude, longitude: longitude, timeZone: timeZone)
    let sun = { (t: Date) in sunAltitude(observer, t) }
    let moon = { (t: Date) -> Double in
      let body = SolarSystem.moon(at: t)
      let geocentric = Transform.horizontal(body.equatorial, observer: observer, at: t).altitude
      return geocentric - body.parallax * cosd(geocentric)
    }
    let rise = crossings(sun, level: horizon, in: window)
    let golden = crossings(sun, level: goldenTop, in: window)
    let goldenEdge = crossings(sun, level: goldenBottom, in: window)
    let civilLight = crossings(sun, level: civil, in: window)
    let moonEvents = crossings(moon, level: horizon, in: window)
    let phase = SolarSystem.moonPhase(at: rise.falling ?? window.start.addingTimeInterval(window.duration * 0.8))
    return Daylight(
      sunrise: rise.rising,
      sunset: rise.falling,
      solarNoon: highest(sun, in: window),
      morningGoldenEnd: golden.rising,
      eveningGoldenStart: golden.falling,
      eveningGoldenEnd: goldenEdge.falling,
      morningGoldenStart: goldenEdge.rising,
      firstLight: civilLight.rising,
      lastLight: civilLight.falling,
      moonrise: moonEvents.rising,
      moonset: moonEvents.falling,
      moonIllumination: phase.illumination,
      moonWaxing: phase.isWaxing
    )
  }

  /// Where the Sun is, apparent altitude and azimuth in degrees.
  public static func sun(at date: Date, latitude: Double, longitude: Double) -> Horizontal {
    let observer = Observer(latitude: latitude, longitude: longitude)
    let horizontal = Transform.horizontal(SolarSystem.sun(at: date).equatorial, observer: observer, at: date)
    return Horizontal(altitude: horizontal.altitude + Transform.refraction(atTrueAltitude: horizontal.altitude), azimuth: horizontal.azimuth)
  }

  /// Where the Moon is, topocentric, refraction included.
  public static func moon(at date: Date, latitude: Double, longitude: Double) -> Horizontal {
    let observer = Observer(latitude: latitude, longitude: longitude)
    let body = SolarSystem.moon(at: date)
    let horizontal = Transform.horizontal(body.equatorial, observer: observer, at: date)
    let altitude = horizontal.altitude - body.parallax * cosd(horizontal.altitude)
    return Horizontal(altitude: altitude + Transform.refraction(atTrueAltitude: altitude), azimuth: horizontal.azimuth)
  }

  private static func sunAltitude(_ observer: Observer, _ date: Date) -> Double {
    Transform.horizontal(SolarSystem.sun(at: date).equatorial, observer: observer, at: date).altitude
  }

  private static func crossings(_ f: (Date) -> Double, level: Double, in window: DateInterval) -> (falling: Date?, rising: Date?) {
    var falling: Date?
    var rising: Date?
    var t0 = window.start
    var v0 = f(t0) - level
    while t0 < window.end, falling == nil || rising == nil {
      let t1 = min(t0.addingTimeInterval(step), window.end)
      let v1 = f(t1) - level
      if v0 > 0, v1 <= 0, falling == nil {
        falling = bisect({ f($0) - level }, from: t0, to: t1)
      } else if v0 <= 0, v1 > 0, rising == nil {
        rising = bisect({ f($0) - level }, from: t0, to: t1)
      }
      t0 = t1
      v0 = v1
    }
    return (falling, rising)
  }

  private static func highest(_ f: (Date) -> Double, in window: DateInterval) -> Date? {
    let samples = stride(from: window.start, through: window.end, by: step).map { ($0, f($0)) }
    guard let best = samples.max(by: { $0.1 < $1.1 }) else {
      return nil
    }
    var lo = max(window.start, best.0.addingTimeInterval(-step))
    var hi = min(window.end, best.0.addingTimeInterval(step))
    for _ in 0..<30 {
      let a = lo.addingTimeInterval(hi.timeIntervalSince(lo) / 3)
      let b = lo.addingTimeInterval(hi.timeIntervalSince(lo) * 2 / 3)
      if f(a) < f(b) {
        lo = a
      } else {
        hi = b
      }
    }
    return lo.addingTimeInterval(hi.timeIntervalSince(lo) / 2)
  }

  private static func bisect(_ f: (Date) -> Double, from a: Date, to b: Date) -> Date {
    var lo = a
    var hi = b
    let rising = f(a) < f(b)
    for _ in 0..<20 {
      let mid = lo.addingTimeInterval(hi.timeIntervalSince(lo) / 2)
      if (f(mid) < 0) == rising {
        lo = mid
      } else {
        hi = mid
      }
    }
    return lo.addingTimeInterval(hi.timeIntervalSince(lo) / 2)
  }
}
