import Foundation
import SkyKit
import Testing

/// Sentinel Dome, Yosemite, 24 October 2026, checked against PyEphem.
@Test func sentinelDomeEvening() {
  let zone = TimeZone(identifier: "America/Los_Angeles")!
  var calendar = Calendar(identifier: .gregorian)
  calendar.timeZone = zone
  let noon = calendar.date(from: DateComponents(year: 2026, month: 10, day: 24, hour: 12))!
  let day = DaylightCalculator.day(containing: noon, latitude: 37.7236, longitude: -119.5843, timeZone: zone)
  let format = Date.FormatStyle(date: .omitted, time: .shortened, timeZone: zone)
  print("sunrise", day.sunrise!.formatted(format), "sunset", day.sunset!.formatted(format))
  print("golden", day.eveningGoldenStart!.formatted(format), "-", day.eveningGoldenEnd!.formatted(format), "last light", day.lastLight!.formatted(format))
  print("moonrise", day.moonrise.map { $0.formatted(format) } ?? "none", "illumination", day.moonIllumination)
  #expect(day.sunset != nil)
}
