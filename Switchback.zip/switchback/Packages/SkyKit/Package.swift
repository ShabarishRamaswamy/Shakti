// swift-tools-version: 6.2
import PackageDescription

let package = Package(
  name: "SkyKit",
  platforms: [.iOS("26.4"), .macOS("26.0")],
  products: [
    // Sun and Moon positions, rise and set: pure Foundation, no network. Trimmed from Nightjar.
    .library(name: "SkyKit", targets: ["SkyKit"])
  ],
  targets: [
    .target(name: "SkyKit"),
    .testTarget(name: "SkyKitTests", dependencies: ["SkyKit"])
  ]
)
